export interface MenuItem {
  id: string;
  name: string;
  category: string;
  price: number;
  priceLabel: string;
  image: string;
  description: string;
  bestseller?: boolean;
}

export interface Category {
  id: string;
  name: string;
  icon: string;
}

export const categories: Category[] = [
  { id: 'seblak', name: 'Seblak', icon: '🍜' },
  { id: 'favorites', name: 'Wajib Coba', icon: '🔥' },
  { id: 'lainnya', name: 'Menu Lain', icon: '🍽️' },
  { id: 'coupons', name: 'Kupon Promo', icon: '🎟️' },
];

export const menuItems: MenuItem[] = [
  // SEBLAK
  { id: 's1', name: 'Seblak Original', category: 'seblak', price: 12000, priceLabel: '12K', image: '🍜', description: 'Kerupuk, pentol, sosis, sayuran, telur, mie', bestseller: true },
  { id: 's2', name: 'Seblak Jumbo', category: 'seblak', price: 16000, priceLabel: '16K', image: '🍜', description: 'Seblak ori + sosis pentol double + topoki + somay' },
  { id: 's3', name: 'Seblak Cuanki', category: 'seblak', price: 22000, priceLabel: '22K', image: '🍲', description: 'Seblak ori + pentol aci + cuanki lidah + cuanki tahu + somay kering + pilus' },
  { id: 's4', name: 'Seblak Mix Suki', category: 'seblak', price: 25000, priceLabel: '25K', image: '🍲', description: 'Seblak ori + dumpling keju + chikuwa + crabstick + siomay + bola ikan + topoki' },
  { id: 's5', name: 'Seblak Komplit', category: 'seblak', price: 35000, priceLabel: '35K', image: '🍲', description: 'Seblak ori + dumpling keju + bola ikan + bola salmon + bola lobster + pentol aci + kembang cumi + ceker + jamur enoki', bestseller: true },

  // WAJIB COBA
  { id: 'w1', name: 'Indomie Nyemek Kornet (INK)', category: 'favorites', price: 15000, priceLabel: '15K', image: '🍝', description: 'Indomie goreng nyemek dengan kornet sapi' },
  { id: 'w2', name: 'Pentol Aci Mercon', category: 'favorites', price: 12000, priceLabel: '12K', image: '🌶️', description: 'Pentol aci dengan sambal mercon pedas nampol' },
  { id: 'w3', name: 'Mie Jebew', category: 'favorites', price: 12000, priceLabel: '12K', image: '🍜', description: 'Mie jebew dengan topping kacang dan sambal' },
  { id: 'w4', name: 'Ceker Mercon', category: 'favorites', price: 12000, priceLabel: '12K', image: '🐔', description: 'Ceker ayam pedas mercon' },
  { id: 'w5', name: 'Ayam Oseng', category: 'favorites', price: 12000, priceLabel: '12K', image: '🍗', description: 'Nasi dengan ayam oseng pedas' },
  { id: 'w6', name: 'Rice Bowl Katsu BBQ', category: 'favorites', price: 12000, priceLabel: '12K', image: '🍚', description: 'Nasi dengan katsu ayam saus BBQ' },
  { id: 'w7', name: 'Ceker Enoki Mercon', category: 'favorites', price: 16000, priceLabel: '16K', image: '🍄', description: 'Ceker dengan jamur enoki dan sambal mercon' },

  // MENU LAIN
  { id: 'l1', name: 'Oseng Tempura Mix', category: 'lainnya', price: 12000, priceLabel: '12K', image: '🍤', description: 'Oseng tempura campur pedas' },
  { id: 'l2', name: 'Tempura Goreng Mix', category: 'lainnya', price: 12000, priceLabel: '12K', image: '🍤', description: 'Tempura goreng campur crispy' },
  { id: 'l3', name: 'Tahu Bakso', category: 'lainnya', price: 10000, priceLabel: '10K', image: '🧆', description: 'Tahu bakso goreng pedas' },
  { id: 'l4', name: 'Kentang Goreng', category: 'lainnya', price: 12000, priceLabel: '12K', image: '🍟', description: 'Kentang goreng crispy' },

  // KUPON PROMO
  { id: 'p1', name: 'Beli 2 Gratis 1 Seblak', category: 'coupons', price: 24000, priceLabel: '24K', image: '🎟️', description: 'Beli 2 seblak original gratis 1' },
  { id: 'p2', name: 'Paket Hemat Keluarga', category: 'coupons', price: 60000, priceLabel: '60K', image: '🎟️', description: '3 Seblak + 3 Minuman' },
  { id: 'p3', name: 'Diskon QRIS 10%', category: 'coupons', price: 0, priceLabel: '0K', image: '🎟️', description: 'Diskon 10% untuk pembayaran QRIS' },
];

export interface Order {
  id: string;
  items: { item: MenuItem; qty: number; level: number }[];
  total: number;
  status: 'pending' | 'preparing' | 'ready' | 'served' | 'cancelled';
  type: 'kiosk' | 'cashier';
  paymentMethod: 'cash' | 'card' | 'qris';
  customerName?: string;
  note?: string;
  createdAt: Date;
}

export function formatRupiah(n: number): string {
  return 'Rp ' + n.toLocaleString('id-ID');
}

export const initialOrders: Order[] = [
  { id: 'ORD-10234', items: [{ item: menuItems[0], qty: 2, level: 3 }, { item: menuItems[7], qty: 1, level: 5 }], total: 36000, status: 'preparing', type: 'kiosk', paymentMethod: 'qris', customerName: 'Table 7', note: 'Extra pedas', createdAt: new Date(Date.now() - 300000) },
  { id: 'ORD-10235', items: [{ item: menuItems[4], qty: 1, level: 4 }], total: 35000, status: 'pending', type: 'cashier', paymentMethod: 'cash', customerName: 'Walk-in', createdAt: new Date(Date.now() - 120000) },
  { id: 'ORD-10236', items: [{ item: menuItems[5], qty: 1, level: 2 }, { item: menuItems[9], qty: 1, level: 1 }], total: 27000, status: 'ready', type: 'kiosk', paymentMethod: 'card', customerName: 'Table 3', createdAt: new Date(Date.now() - 60000) },
];
