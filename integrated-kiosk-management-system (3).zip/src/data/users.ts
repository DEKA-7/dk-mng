export interface User {
  username: string;
  password: string;
  name: string;
  role: 'admin' | 'cashier' | 'kitchen' | 'finance' | 'marketing';
  avatar: string;
  outlet: string;
}

export const defaultUsers: User[] = [
  { username: 'admin', password: 'admin123', name: 'Administrator', role: 'admin', avatar: '👑', outlet: 'Outlet Utama' },
  { username: 'kasir', password: 'kasir123', name: 'Kasir Siti', role: 'cashier', avatar: '💰', outlet: 'Outlet Utama' },
  { username: 'dapur', password: 'dapur123', name: 'Chef Budi', role: 'kitchen', avatar: '🍳', outlet: 'Outlet Utama' },
  { username: 'keuangan', password: 'keu123', name: 'Finance Ani', role: 'finance', avatar: '📈', outlet: 'Outlet Utama' },
  { username: 'marketing', password: 'mark123', name: 'Marketing Dewi', role: 'marketing', avatar: '🎯', outlet: 'Outlet Utama' },
];
