import { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { StoreProvider } from './context/StoreContext';
import { SettingsProvider } from './context/SettingsContext';
import { ActivityProvider } from './context/ActivityContext';
import Kiosk from './pages/Kiosk';
import Cashier from './pages/Cashier';
import Kitchen from './pages/Kitchen';
import Finance from './pages/Finance';
import Marketing from './pages/Marketing';
import Dashboard from './pages/Dashboard';
import Login from './pages/Login';
import Settings from './pages/Settings';
import Backup from './pages/Backup';

type Page = 'dashboard' | 'kiosk' | 'cashier' | 'kitchen' | 'finance' | 'marketing' | 'settings' | 'backup';

const navItems: { id: Page; label: string; icon: string; color: string; roles: string[] }[] = [
  { id: 'dashboard', label: 'Dashboard', icon: '📊', color: 'from-amber-600 to-red-800', roles: ['admin', 'cashier', 'kitchen', 'finance', 'marketing'] },
  { id: 'kiosk', label: 'Kiosk', icon: '🖥️', color: 'from-red-500 to-red-700', roles: ['admin', 'cashier'] },
  { id: 'cashier', label: 'Kasir', icon: '💰', color: 'from-orange-500 to-red-600', roles: ['admin', 'cashier'] },
  { id: 'kitchen', label: 'Dapur', icon: '🍳', color: 'from-emerald-500 to-teal-600', roles: ['admin', 'kitchen'] },
  { id: 'finance', label: 'Keuangan', icon: '📈', color: 'from-blue-500 to-indigo-600', roles: ['admin', 'finance'] },
  { id: 'marketing', label: 'Pemasaran', icon: '🎯', color: 'from-purple-500 to-pink-600', roles: ['admin', 'marketing'] },
  { id: 'settings', label: 'Pengaturan', icon: '⚙️', color: 'from-slate-500 to-slate-700', roles: ['admin'] },
  { id: 'backup', label: 'Backup', icon: '💾', color: 'from-cyan-500 to-blue-600', roles: ['admin'] },
];

function AppContent() {
  const { user, logout, isAdmin } = useAuth();
  const [page, setPage] = useState<Page>(getDefaultPage(user?.role));

  // Show kiosk mode for public (no login) or logged-in users with access
  if (!user) {
    return (
      <StoreProvider>
        <SettingsProvider>
          <ActivityProvider>
            <Login />
          </ActivityProvider>
        </SettingsProvider>
      </StoreProvider>
    );
  }

  const visibleNav = navItems.filter(n => n.roles.includes(user.role));
  const currentPage = visibleNav.find(n => n.id === page) ? page : visibleNav[0]?.id || 'dashboard';

  return (
    <div className="flex min-h-screen bg-gradient-to-br from-red-950 via-amber-950 to-red-950">
      {/* Sidebar */}
      <aside className="w-64 bg-black/50 backdrop-blur-xl text-white flex flex-col fixed h-screen border-r border-red-500/20 z-20">
        <div className="p-5 border-b border-red-500/20">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-red-500 via-orange-500 to-yellow-500 flex items-center justify-center font-bold text-xl shadow-lg shadow-red-500/50">
              🌶️
            </div>
            <div>
              <h1 className="font-black text-lg leading-tight tracking-wide">SEBLAKIDR</h1>
              <p className="text-[10px] text-amber-300 font-bold tracking-widest">PEDAS NAMPOL</p>
            </div>
          </div>
        </div>
        <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
          {visibleNav.map(item => (
            <button
              key={item.id}
              onClick={() => setPage(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-left transition-all ${
                currentPage === item.id
                  ? `bg-gradient-to-r ${item.color} text-white shadow-lg shadow-red-500/30`
                  : 'text-slate-300 hover:bg-white/10 hover:text-white'
              }`}
            >
              <span className="text-xl">{item.icon}</span>
              <span className="font-bold">{item.label}</span>
              {currentPage === item.id && <span className="ml-auto text-[10px] bg-white/20 px-2 py-0.5 rounded font-bold">ACTIVE</span>}
            </button>
          ))}
        </nav>
        <div className="p-4 border-t border-red-500/20">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-amber-400 to-red-500 flex items-center justify-center text-base font-black text-white shadow">
              {user.avatar}
            </div>
            <div className="flex-1 min-w-0">
              <div className="font-black text-white truncate">{user.name}</div>
              <div className="text-xs text-amber-300/80 capitalize">{user.role}</div>
            </div>
          </div>
          <button onClick={logout} className="w-full py-2 bg-white/10 hover:bg-red-500/30 text-white text-sm font-bold rounded-lg transition">
            🚪 Logout
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 ml-64 overflow-auto">
        {currentPage === 'dashboard' && <Dashboard onNavigate={setPage} visibleNav={visibleNav.map(n => n.id)} />}
        {currentPage === 'kiosk' && <Kiosk />}
        {currentPage === 'cashier' && <Cashier />}
        {currentPage === 'kitchen' && <Kitchen />}
        {currentPage === 'finance' && <Finance />}
        {currentPage === 'marketing' && <Marketing />}
        {currentPage === 'settings' && isAdmin && <Settings />}
        {currentPage === 'backup' && isAdmin && <Backup />}
      </main>
    </div>
  );
}

function getDefaultPage(role?: string): Page {
  if (!role) return 'dashboard';
  if (role === 'admin') return 'dashboard';
  if (role === 'cashier') return 'cashier';
  if (role === 'kitchen') return 'kitchen';
  if (role === 'finance') return 'finance';
  if (role === 'marketing') return 'marketing';
  return 'dashboard';
}

export default function App() {
  return (
    <AuthProvider>
      <StoreProvider>
        <SettingsProvider>
          <ActivityProvider>
            <AppContent />
          </ActivityProvider>
        </SettingsProvider>
      </StoreProvider>
    </AuthProvider>
  );
}
