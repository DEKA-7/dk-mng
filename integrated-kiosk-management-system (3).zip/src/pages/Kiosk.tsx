import { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { categories, menuItems, MenuItem, formatRupiah } from '../data/menuData';

export default function Kiosk() {
  const { cart, addToCart, updateQty, removeFromCart, updateLevel, cartTotal, cartCount, clearCart, addOrder, getUniqueCustomerName } = useStore();
  const [activeCategory, setActiveCategory] = useState('seblak');
  const [showCart, setShowCart] = useState(false);
  const [checkoutStep, setCheckoutStep] = useState<'menu' | 'payment' | 'success'>('menu');
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'card' | 'qris'>('qris');
  const [lastOrder, setLastOrder] = useState<string>('');

  const items = menuItems.filter(m => m.category === activeCategory);

  const handleCheckout = () => {
    if (cart.length === 0) return;
    const orderId = addOrder({
      items: cart,
      total: cartTotal,
      status: 'pending',
      type: 'kiosk',
      paymentMethod,
      customerName: getUniqueCustomerName(`Pelanggan ${Math.floor(Math.random() * 100) + 1}`),
    });
    setLastOrder(orderId);
    clearCart();
    setCheckoutStep('success');
    setTimeout(() => { setCheckoutStep('menu'); setShowCart(false); }, 4000);
  };

  if (checkoutStep === 'success') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-red-950 via-orange-950 to-red-950 p-8">
        <div className="bg-gradient-to-br from-red-900/90 to-orange-900/90 backdrop-blur-2xl rounded-3xl p-10 shadow-2xl max-w-md text-center border-2 border-red-500/40">
          <div className="w-24 h-24 mx-auto rounded-full bg-gradient-to-br from-emerald-400 to-emerald-600 flex items-center justify-center text-white text-5xl mb-4 shadow-xl shadow-emerald-500/50">✓</div>
          <h2 className="text-3xl font-black text-white mb-2">PESANAN BERHASIL! 🌶️</h2>
          <p className="text-amber-300 mb-6">Terima kasih telah memesan di SeblakIDR</p>
          <div className="bg-black/40 rounded-2xl p-5 mb-4 border border-red-500/30">
            <div className="text-xs text-amber-300/80 mb-1">Nomor Pesanan</div>
            <div className="text-3xl font-black text-amber-300 tracking-wider">{lastOrder}</div>
          </div>
          <div className="text-sm text-amber-200/80">Silakan ambil pesanan di counter saat nomor dipanggil</div>
          <div className="mt-4 text-xs text-amber-400/60">Pedasnya Nampol, Rasanya Nagih! 🔥</div>
        </div>
      </div>
    );
  }

  if (checkoutStep === 'payment') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-950 via-orange-950 to-red-950 p-8">
        <div className="max-w-2xl mx-auto">
          <button onClick={() => setCheckoutStep('menu')} className="mb-4 text-amber-300 hover:text-white flex items-center gap-2 font-semibold">
            <span>←</span> Kembali ke menu
          </button>
          <div className="bg-gradient-to-br from-red-900/80 to-orange-900/80 backdrop-blur-xl rounded-3xl p-8 shadow-2xl border-2 border-red-500/30">
            <h2 className="text-2xl font-black text-white mb-2">💳 Pilih Metode Pembayaran</h2>
            <p className="text-amber-300/80 mb-6">Total: <span className="text-amber-300 font-black text-2xl">{formatRupiah(cartTotal)}</span></p>

            <div className="space-y-3 mb-6">
              {[
                { id: 'qris', label: 'QRIS', icon: '📱', desc: 'Scan QR code dengan e-wallet', recommended: true },
                { id: 'card', label: 'Kartu Debit/Kredit', icon: '💳', desc: 'Visa, Mastercard, JCB' },
                { id: 'cash', label: 'Tunai', icon: '💵', desc: 'Bayar di counter kasir' },
              ].map(pm => (
                <button
                  key={pm.id}
                  onClick={() => setPaymentMethod(pm.id as any)}
                  className={`w-full flex items-center gap-4 p-4 rounded-2xl border-2 transition-all ${
                    paymentMethod === pm.id ? 'border-amber-400 bg-amber-400/20' : 'border-white/20 hover:border-amber-400/50 bg-white/5'
                  }`}
                >
                  <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-red-600 to-orange-600 flex items-center justify-center text-3xl shadow-lg">{pm.icon}</div>
                  <div className="flex-1 text-left">
                    <div className="font-black text-white flex items-center gap-2">
                      {pm.label}
                      {pm.recommended && <span className="text-[10px] bg-amber-400 text-red-900 px-2 py-0.5 rounded-full font-bold">REKOMENDASI</span>}
                    </div>
                    <div className="text-xs text-amber-200/70">{pm.desc}</div>
                  </div>
                  <div className={`w-7 h-7 rounded-full border-2 ${paymentMethod === pm.id ? 'border-amber-400 bg-amber-400' : 'border-white/30'} flex items-center justify-center text-red-900 text-xs font-black`}>
                    {paymentMethod === pm.id && '✓'}
                  </div>
                </button>
              ))}
            </div>

            {paymentMethod === 'qris' && (
              <div className="bg-white/10 rounded-2xl p-6 text-center mb-6 border border-amber-400/30">
                <div className="w-48 h-48 mx-auto bg-white rounded-2xl flex items-center justify-center text-6xl shadow-xl">
                  ⬛
                </div>
                <p className="text-sm text-amber-200 mt-4">Scan QR code dengan aplikasi e-wallet Anda</p>
                <p className="text-xs text-amber-300/60 mt-1">GO-PAY, OVO, DANA, ShopeePay</p>
              </div>
            )}

            <button
              onClick={handleCheckout}
              className="w-full py-4 bg-gradient-to-r from-red-500 via-orange-500 to-amber-500 text-white font-black rounded-2xl shadow-xl shadow-red-500/50 hover:shadow-2xl transition-all text-lg"
            >
              🔥 BAYAR {formatRupiah(cartTotal)}
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-gradient-to-br from-red-950 via-orange-950 to-red-950">
      {/* Sidebar - Categories */}
      <aside className="w-60 bg-black/50 backdrop-blur-xl border-r border-red-500/20 flex flex-col">
        <div className="p-5 border-b border-red-500/20">
          <div className="w-16 h-16 mx-auto rounded-2xl bg-gradient-to-br from-red-500 via-orange-500 to-yellow-500 flex items-center justify-center text-4xl shadow-xl shadow-red-500/50">
            🌶️
          </div>
          <h1 className="text-center font-black text-xl mt-3 text-white tracking-wider">SEBLAKIDR</h1>
          <p className="text-center text-[10px] text-amber-300 font-bold tracking-widest">PEDAS NAMPOL</p>
        </div>
        <nav className="flex-1 overflow-y-auto p-3 space-y-1">
          {categories.map(cat => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-left transition-all ${
                activeCategory === cat.id ? 'bg-gradient-to-r from-red-500 to-orange-600 text-white shadow-lg shadow-red-500/30' : 'text-amber-200/80 hover:bg-white/10 hover:text-white'
              }`}
            >
              <span className="text-xl">{cat.icon}</span>
              <span className="text-sm font-bold">{cat.name}</span>
            </button>
          ))}
        </nav>
        <div className="p-3 border-t border-red-500/20">
          <button onClick={() => { clearCart(); setShowCart(false); }} className="w-full text-xs text-amber-300/70 hover:text-white flex items-center justify-center gap-1 py-2 rounded-lg hover:bg-white/10">
            <span>↻</span> <span className="font-bold">RESTART</span>
          </button>
        </div>
      </aside>

      {/* Main Menu Area */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="bg-black/40 backdrop-blur-xl border-b border-red-500/20 px-8 py-5">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-3xl font-black text-white uppercase tracking-tight">{categories.find(c => c.id === activeCategory)?.name}</h2>
              <p className="text-sm text-amber-300/80 mt-1">🔥 Pedasnya Nampol, Rasanya Nagih!</p>
            </div>
            <div className="text-right">
              <div className="text-xs text-amber-300/60">Kiosk #01</div>
              <div className="font-bold text-white">Selamat Datang 👋</div>
            </div>
          </div>
        </div>

        {/* Menu Grid */}
        <div className="flex-1 overflow-y-auto p-6">
          <div className="grid grid-cols-3 gap-5">
            {items.map((item: MenuItem) => (
              <button
                key={item.id}
                onClick={() => addToCart(item, 1)}
                className="group bg-gradient-to-br from-white/10 to-white/5 backdrop-blur-xl rounded-2xl p-5 shadow-xl hover:shadow-2xl hover:shadow-red-500/30 transition-all text-left border-2 border-white/10 hover:border-amber-400/60 hover:-translate-y-1"
              >
                <div className="relative">
                  <div className="aspect-square bg-gradient-to-br from-red-600/40 via-orange-500/40 to-amber-400/40 rounded-2xl flex items-center justify-center text-7xl mb-4 shadow-inner">
                    {item.image}
                  </div>
                  {item.bestseller && (
                    <span className="absolute -top-2 -left-2 bg-gradient-to-r from-red-500 to-orange-500 text-white text-[10px] px-3 py-1.5 rounded-full font-black shadow-lg border-2 border-amber-300">
                      🔥 BEST SELLER
                    </span>
                  )}
                </div>
                <h3 className="font-black text-white text-lg group-hover:text-amber-300 transition-colors">{item.name}</h3>
                <p className="text-xs text-amber-200/70 mt-1.5 line-clamp-2 leading-relaxed">{item.description}</p>
                <div className="flex items-center justify-between mt-4">
                  <div>
                    <span className="text-xs text-amber-300/70 line-through">Rp {item.price + 2000}</span>
                    <div className="text-2xl font-black text-amber-300">{item.priceLabel}</div>
                  </div>
                  <span className="w-10 h-10 rounded-full bg-gradient-to-br from-red-500 to-orange-600 text-white flex items-center justify-center text-2xl group-hover:scale-110 transition-transform shadow-lg">+</span>
                </div>
              </button>
            ))}
            {items.length === 0 && (
              <div className="col-span-3 text-center py-20 text-amber-300/50">Tidak ada item di kategori ini</div>
            )}
          </div>
        </div>

        {/* Cart Bar */}
        <div className="bg-black/60 backdrop-blur-2xl border-t-2 border-amber-500/40 px-6 py-4">
          {!showCart ? (
            <div className="flex items-center justify-between">
              <button onClick={() => setShowCart(true)} className="flex items-center gap-3 px-5 py-3 bg-white/10 hover:bg-white/15 rounded-2xl transition border border-white/10">
                <div className="relative">
                  <span className="text-2xl">🛒</span>
                  {cartCount > 0 && (
                    <span className="absolute -top-2 -right-2 bg-amber-400 text-red-900 text-xs w-6 h-6 rounded-full flex items-center justify-center font-black shadow-lg">{cartCount}</span>
                  )}
                </div>
                <div className="text-left">
                  <div className="text-xs text-amber-300/70">{cartCount} item</div>
                  <div className="font-black text-white">SHOW BASKET</div>
                </div>
              </button>
              <button
                onClick={() => setCheckoutStep('payment')}
                disabled={cart.length === 0}
                className={`px-10 py-4 rounded-2xl font-black text-white shadow-xl transition-all ${
                  cart.length > 0 ? 'bg-gradient-to-r from-red-500 via-orange-500 to-amber-500 hover:shadow-2xl hover:shadow-red-500/50 text-lg' : 'bg-slate-700 cursor-not-allowed'
                }`}
              >
                🔥 PLACE ORDER {formatRupiah(cartTotal)}
              </button>
            </div>
          ) : (
            <div className="max-h-96 overflow-y-auto">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-black text-white text-lg">🛒 Pesanan Anda ({cartCount})</h3>
                <button onClick={() => setShowCart(false)} className="text-amber-300/60 hover:text-white text-xl">▼</button>
              </div>
              {cart.length === 0 ? (
                <div className="text-center py-8 text-amber-300/50">Keranjang kosong</div>
              ) : (
                <>
                  <div className="space-y-2 mb-4">
                    {cart.map(c => (
                      <div key={c.item.id} className="flex items-center gap-3 p-3 bg-white/5 rounded-2xl border border-white/10">
                        <div className="w-14 h-14 bg-gradient-to-br from-red-600/40 to-orange-500/40 rounded-xl flex items-center justify-center text-2xl">{c.item.image}</div>
                        <div className="flex-1 min-w-0">
                          <div className="font-bold text-white text-sm truncate">{c.item.name}</div>
                          <div className="text-amber-300 font-bold text-sm">{formatRupiah(c.item.price)}</div>
                          <select
                            value={c.level}
                            onChange={e => updateLevel(c.item.id, parseInt(e.target.value))}
                            className="mt-1 text-xs bg-red-900/40 text-amber-200 border border-red-500/30 rounded px-2 py-0.5 focus:outline-none"
                          >
                            {[1,2,3,4,5,6,7].map(l => (
                              <option key={l} value={l}>Level {l}{l === 6 ? ' (+2K)' : l === 7 ? ' (+4K)' : ''}</option>
                            ))}
                          </select>
                        </div>
                        <div className="flex items-center gap-1">
                          <button onClick={() => updateQty(c.item.id, c.qty - 1)} className="w-8 h-8 rounded-full bg-white/10 hover:bg-red-500/40 flex items-center justify-center text-white">−</button>
                          <span className="w-8 text-center font-black text-white">{c.qty}</span>
                          <button onClick={() => updateQty(c.item.id, c.qty + 1)} className="w-8 h-8 rounded-full bg-white/10 hover:bg-red-500/40 flex items-center justify-center text-white">+</button>
                        </div>
                        <button onClick={() => removeFromCart(c.item.id)} className="text-amber-300/50 hover:text-red-400 text-sm">✕</button>
                      </div>
                    ))}
                  </div>
                  <div className="flex items-center justify-between pt-4 border-t border-white/10">
                    <div>
                      <div className="text-xs text-amber-300/70">Total</div>
                      <div className="text-3xl font-black text-amber-300">{formatRupiah(cartTotal)}</div>
                    </div>
                    <button
                      onClick={() => setCheckoutStep('payment')}
                      className="px-10 py-4 rounded-2xl font-black text-white bg-gradient-to-r from-red-500 via-orange-500 to-amber-500 shadow-xl shadow-red-500/50 hover:shadow-2xl"
                    >
                      CHECKOUT →
                    </button>
                  </div>
                </>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
