import { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { menuItems, categories, formatRupiah } from '../data/menuData';

export default function Cashier() {
  const { addToCart, cart, updateQty, removeFromCart, cartTotal, cartCount, clearCart, addOrder, getUniqueCustomerName } = useStore();
  const [activeCategory, setActiveCategory] = useState('all');
  const [customerName, setCustomerName] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'card' | 'qris'>('cash');
  const [cashGiven, setCashGiven] = useState('');
  const [showSuccess, setShowSuccess] = useState<string | null>(null);

  const filteredItems = activeCategory === 'all' ? menuItems.filter(m => m.category !== 'coupons') : menuItems.filter(m => m.category === activeCategory);
  const cashNum = parseFloat(cashGiven) || 0;
  const change = cashNum - cartTotal;

  const handlePayment = () => {
    if (cart.length === 0) return;
    if (paymentMethod === 'cash' && cashNum < cartTotal) return;
    const orderId = addOrder({
      items: cart,
      total: cartTotal,
      status: 'pending',
      type: 'cashier',
      paymentMethod,
      customerName: getUniqueCustomerName(customerName || 'Walk-in'),
    });
    setShowSuccess(orderId);
    clearCart();
    setCustomerName('');
    setCashGiven('');
    setTimeout(() => setShowSuccess(null), 3000);
  };

  if (showSuccess) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-red-950 via-orange-950 to-red-950 p-8">
        <div className="bg-gradient-to-br from-red-900/90 to-orange-900/90 backdrop-blur-2xl rounded-3xl p-10 shadow-2xl max-w-md text-center border-2 border-orange-400/40">
          <div className="w-24 h-24 mx-auto rounded-full bg-gradient-to-br from-emerald-400 to-emerald-600 flex items-center justify-center text-white text-5xl mb-4 shadow-xl">✓</div>
          <h2 className="text-2xl font-black text-white mb-2">PEMBAYARAN BERHASIL! 🔥</h2>
          <div className="bg-black/40 rounded-2xl p-4 mb-4 border border-orange-400/30">
            <div className="text-xs text-amber-300/80">Nomor Pesanan</div>
            <div className="text-2xl font-black text-amber-300">{showSuccess}</div>
          </div>
          <div className="text-sm text-amber-200/80">Pesanan diteruskan ke dapur</div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-gradient-to-br from-red-950 via-orange-950 to-red-950">
      {/* Menu side */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <div className="bg-black/40 backdrop-blur-xl border-b border-red-500/20 px-6 py-4">
          <h1 className="text-2xl font-black text-white">💰 Kasir Counter</h1>
          <p className="text-sm text-amber-300/70">Transaksi penjualan langsung</p>
        </div>
        <div className="px-6 py-3 bg-black/30 border-b border-red-500/10 backdrop-blur">
          <div className="flex gap-2 overflow-x-auto">
            <button onClick={() => setActiveCategory('all')} className={`px-4 py-1.5 rounded-full text-sm font-bold whitespace-nowrap ${activeCategory === 'all' ? 'bg-gradient-to-r from-orange-500 to-red-600 text-white shadow-lg' : 'bg-white/10 text-amber-200/80'}`}>
              Semua Menu
            </button>
            {categories.filter(c => c.id !== 'coupons').map(c => (
              <button key={c.id} onClick={() => setActiveCategory(c.id)} className={`px-4 py-1.5 rounded-full text-sm font-bold whitespace-nowrap ${activeCategory === c.id ? 'bg-gradient-to-r from-orange-500 to-red-600 text-white shadow-lg' : 'bg-white/10 text-amber-200/80'}`}>
                {c.icon} {c.name}
              </button>
            ))}
          </div>
        </div>
        <div className="flex-1 overflow-y-auto p-4">
          <div className="grid grid-cols-3 gap-3">
            {filteredItems.map(item => (
              <button
                key={item.id}
                onClick={() => addToCart(item, 1)}
                className="bg-white/10 backdrop-blur-xl rounded-2xl p-4 shadow-lg hover:shadow-xl hover:border-orange-400/60 border-2 border-transparent transition-all text-left hover:-translate-y-0.5"
              >
                <div className="aspect-square bg-gradient-to-br from-red-600/40 via-orange-500/40 to-amber-400/40 rounded-xl flex items-center justify-center text-5xl mb-3 shadow-inner">{item.image}</div>
                <div className="font-bold text-white text-sm truncate">{item.name}</div>
                <div className="text-amber-300 font-black">{item.priceLabel}</div>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Cart side */}
      <aside className="w-[420px] bg-black/60 backdrop-blur-2xl border-l-2 border-orange-500/30 flex flex-col">
        <div className="p-5 border-b border-red-500/20 bg-gradient-to-br from-orange-600 to-red-700 text-white">
          <div className="text-sm opacity-90">Keranjang ({cartCount})</div>
          <div className="text-3xl font-black tracking-tight">{formatRupiah(cartTotal)}</div>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-2">
          {cart.length === 0 ? (
            <div className="text-center py-10 text-amber-300/50">
              <div className="text-5xl mb-2">🛒</div>
              <div className="text-sm">Keranjang kosong</div>
            </div>
          ) : (
            cart.map(c => (
              <div key={c.item.id} className="flex items-center gap-3 p-3 bg-white/5 rounded-xl border border-white/10">
                <div className="w-11 h-11 bg-gradient-to-br from-red-600/40 to-orange-500/40 rounded-xl flex items-center justify-center text-xl">{c.item.image}</div>
                <div className="flex-1 min-w-0">
                  <div className="font-bold text-xs text-white truncate">{c.item.name}</div>
                  <div className="text-amber-300 font-bold text-xs">{formatRupiah(c.item.price)}</div>
                  <div className="text-[10px] text-amber-400/70 mt-0.5">Lv.{c.level}{c.level >= 6 ? ' +' + formatRupiah(c.level >= 7 ? 4000 : 2000).replace('Rp ', '') : ''}</div>
                </div>
                <div className="flex items-center gap-1">
                  <button onClick={() => updateQty(c.item.id, c.qty - 1)} className="w-7 h-7 rounded-full bg-white/10 hover:bg-red-500/40 flex items-center justify-center text-white text-xs">−</button>
                  <span className="w-5 text-center text-xs font-black text-white">{c.qty}</span>
                  <button onClick={() => updateQty(c.item.id, c.qty + 1)} className="w-7 h-7 rounded-full bg-white/10 hover:bg-red-500/40 flex items-center justify-center text-white text-xs">+</button>
                </div>
                <button onClick={() => removeFromCart(c.item.id)} className="text-amber-300/40 hover:text-red-400 text-xs">✕</button>
              </div>
            ))
          )}
        </div>

        <div className="p-4 border-t border-red-500/20 space-y-3">
          <input
            type="text"
            placeholder="Nama Pelanggan (opsional)"
            value={customerName}
            onChange={e => setCustomerName(e.target.value)}
            className="w-full px-3 py-2.5 bg-white/10 border border-white/20 rounded-xl text-sm text-white placeholder:text-amber-300/40 focus:outline-none focus:border-orange-400"
          />

          <div>
            <label className="text-xs font-bold text-amber-300/80 block mb-2">Metode Pembayaran</label>
            <div className="grid grid-cols-3 gap-2">
              {(['cash', 'card', 'qris'] as const).map(pm => (
                <button
                  key={pm}
                  onClick={() => setPaymentMethod(pm)}
                  className={`py-2.5 rounded-xl text-xs font-black border-2 ${
                    paymentMethod === pm ? 'border-amber-400 bg-amber-400/20 text-amber-300' : 'border-white/15 text-amber-200/60 bg-white/5'
                  }`}
                >
                  {pm === 'cash' ? '💵 Tunai' : pm === 'card' ? '💳 Kartu' : '📱 QRIS'}
                </button>
              ))}
            </div>
          </div>

          {paymentMethod === 'cash' && (
            <div>
              <label className="text-xs font-bold text-amber-300/80 block mb-2">Jumlah Uang</label>
              <input
                type="number"
                placeholder="0"
                value={cashGiven}
                onChange={e => setCashGiven(e.target.value)}
                className="w-full px-3 py-2.5 bg-white/10 border border-white/20 rounded-xl text-sm text-white placeholder:text-amber-300/40 focus:outline-none focus:border-orange-400"
              />
              {cashNum > 0 && (
                <div className="mt-2 flex justify-between text-sm">
                  <span className="text-amber-300/70">Kembalian:</span>
                  <span className={`font-black ${change >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {formatRupiah(change)}
                  </span>
                </div>
              )}
            </div>
          )}

          <div className="flex gap-2 pt-1">
            <button onClick={clearCart} className="px-4 py-3 bg-white/10 hover:bg-white/15 rounded-xl text-sm font-bold text-amber-200 border border-white/10">
              Bersihkan
            </button>
            <button
              onClick={handlePayment}
              disabled={cart.length === 0 || (paymentMethod === 'cash' && cashNum < cartTotal)}
              className={`flex-1 py-3 rounded-xl font-black text-white text-sm ${
                cart.length === 0 || (paymentMethod === 'cash' && cashNum < cartTotal)
                  ? 'bg-slate-700/60 cursor-not-allowed'
                  : 'bg-gradient-to-r from-red-500 via-orange-500 to-amber-500 shadow-xl shadow-red-500/50 hover:shadow-2xl'
              }`}
            >
              🔥 BAYAR {formatRupiah(cartTotal)}
            </button>
          </div>
        </div>
      </aside>
    </div>
  );
}
