import { useStore } from '../context/StoreContext';
import { Order, formatRupiah } from '../data/menuData';

const statusColors: Record<Order['status'], string> = {
  pending: 'bg-blue-500/20 text-blue-300 border-blue-400/50',
  preparing: 'bg-amber-500/20 text-amber-300 border-amber-400/50',
  ready: 'bg-emerald-500/20 text-emerald-300 border-emerald-400/50',
  served: 'bg-slate-500/20 text-slate-300 border-slate-400/50',
  cancelled: 'bg-rose-500/20 text-rose-300 border-rose-400/50',
};

const statusLabels: Record<Order['status'], string> = {
  pending: 'Menunggu',
  preparing: 'Dimasak',
  ready: 'Siap',
  served: 'Disajikan',
  cancelled: 'Dibatalkan',
};

function timeAgo(date: Date) {
  const diff = Math.floor((Date.now() - date.getTime()) / 60000);
  if (diff < 1) return 'Baru saja';
  if (diff < 60) return `${diff} menit lalu`;
  return `${Math.floor(diff / 60)} jam lalu`;
}

export default function Kitchen() {
  const { orders, updateOrderStatus } = useStore();
  const activeOrders = orders.filter(o => o.status !== 'served' && o.status !== 'cancelled');

  const stats = {
    pending: orders.filter(o => o.status === 'pending').length,
    preparing: orders.filter(o => o.status === 'preparing').length,
    ready: orders.filter(o => o.status === 'ready').length,
    served: orders.filter(o => o.status === 'served').length,
  };

  return (
    <div className="p-6 space-y-6 bg-gradient-to-br from-slate-950 via-red-950 to-slate-950 min-h-screen">
      <div className="flex items-center justify-between text-white">
        <div>
          <div className="inline-flex items-center gap-2 bg-red-500/20 border border-red-500/40 text-amber-300 text-xs px-3 py-1 rounded-full mb-2">
            🔥 PEDASNYA NAMPOL
          </div>
          <h1 className="text-3xl font-black">🍳 Kitchen Display System</h1>
          <p className="text-amber-300/70 text-sm">Dapur - Pantau & kelola pesanan real-time</p>
        </div>
        <div className="text-right">
          <div className="text-xs text-amber-300/70">Shift:</div>
          <div className="font-bold">{new Date().toLocaleTimeString('id-ID')}</div>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-4">
        <div className="bg-blue-500/10 border border-blue-500/30 rounded-2xl p-5">
          <div className="text-xs text-blue-300 font-medium">Menunggu</div>
          <div className="text-4xl font-black text-white">{stats.pending}</div>
        </div>
        <div className="bg-amber-500/10 border border-amber-500/30 rounded-2xl p-5">
          <div className="text-xs text-amber-300 font-medium">Dimasak</div>
          <div className="text-4xl font-black text-white">{stats.preparing}</div>
        </div>
        <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-2xl p-5">
          <div className="text-xs text-emerald-300 font-medium">Siap Disajikan</div>
          <div className="text-4xl font-black text-white">{stats.ready}</div>
        </div>
        <div className="bg-slate-500/10 border border-slate-500/30 rounded-2xl p-5">
          <div className="text-xs text-slate-300 font-medium">Disajikan Hari Ini</div>
          <div className="text-4xl font-black text-white">{stats.served}</div>
        </div>
      </div>

      <div>
        <h2 className="text-white font-black mb-4 text-xl">🔥 Pesanan Aktif ({activeOrders.length})</h2>
        {activeOrders.length === 0 ? (
          <div className="bg-white/5 backdrop-blur rounded-2xl p-16 text-center text-amber-300/50 border border-white/10">
            <div className="text-6xl mb-3">🍽️</div>
            <div className="text-lg">Tidak ada pesanan aktif</div>
          </div>
        ) : (
          <div className="grid grid-cols-3 gap-4">
            {activeOrders.map(order => (
              <div key={order.id} className="bg-gradient-to-br from-red-900/50 to-orange-900/50 backdrop-blur-xl rounded-2xl border-2 border-red-500/30 overflow-hidden shadow-xl">
                <div className="p-4 border-b border-red-500/20 flex items-center justify-between bg-black/30">
                  <div>
                    <div className="text-white font-black text-lg">{order.id}</div>
                    <div className="text-xs text-amber-300/70">
                      {order.type === 'kiosk' ? '🖥️ Kiosk' : '💰 Kasir'} • {order.customerName}
                    </div>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-xs font-black border ${statusColors[order.status]}`}>
                    {statusLabels[order.status]}
                  </span>
                </div>
                <div className="p-4 space-y-2">
                  {order.items.map((i, idx) => (
                    <div key={idx} className="flex items-start gap-3 text-white text-sm bg-white/5 rounded-xl p-2.5">
                      <span className="text-2xl">{i.item.image}</span>
                      <div className="flex-1 min-w-0">
                        <div className="font-bold truncate">{i.item.name}</div>
                        <div className="text-xs text-amber-300/70">Level {i.level}{i.level >= 6 && ' 🌶️🔥'}</div>
                      </div>
                      <span className="bg-gradient-to-br from-red-500 to-orange-600 text-white px-2.5 py-1 rounded-lg text-xs font-black shadow">x{i.qty}</span>
                    </div>
                  ))}
                </div>
                <div className="p-3 border-t border-red-500/20 bg-black/40 flex items-center justify-between">
                  <span className="text-xs text-amber-300/70">
                    {timeAgo(order.createdAt)} • {formatRupiah(order.total)}
                  </span>
                  <div className="flex gap-1">
                    {order.status === 'pending' && (
                      <button onClick={() => updateOrderStatus(order.id, 'preparing')} className="px-3 py-1.5 bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white text-xs font-black rounded-xl shadow">
                        Mulai Memasak
                      </button>
                    )}
                    {order.status === 'preparing' && (
                      <button onClick={() => updateOrderStatus(order.id, 'ready')} className="px-3 py-1.5 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white text-xs font-black rounded-xl shadow">
                        Selesai →
                      </button>
                    )}
                    {order.status === 'ready' && (
                      <button onClick={() => updateOrderStatus(order.id, 'served')} className="px-3 py-1.5 bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 text-white text-xs font-black rounded-xl shadow">
                        Sajikan
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
