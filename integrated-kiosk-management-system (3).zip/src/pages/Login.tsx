import { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useActivity } from '../context/ActivityContext';
import { useSettings } from '../context/SettingsContext';
import { User } from '../data/users';

const roleDescriptions: Record<User['role'], { title: string; desc: string; color: string }> = {
  admin: { title: 'Administrator', desc: 'Akses penuh semua modul & pengaturan', color: 'from-purple-500 to-pink-600' },
  cashier: { title: 'Kasir', desc: 'Transaksi penjualan di counter', color: 'from-orange-500 to-red-600' },
  kitchen: { title: 'Dapur', desc: 'Kelola pesanan dan masakan', color: 'from-emerald-500 to-teal-600' },
  finance: { title: 'Keuangan', desc: 'Laporan & analisa pendapatan', color: 'from-blue-500 to-indigo-600' },
  marketing: { title: 'Pemasaran', desc: 'Kelola promosi & engagement', color: 'from-pink-500 to-rose-600' },
};

export default function Login() {
  const { login } = useAuth();
  const { log } = useActivity();
  const { profile, theme } = useSettings();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [showQuickAccess, setShowQuickAccess] = useState(true);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    const result = login(username, password);
    if (!result.success) {
      setError(result.message || 'Login gagal');
      log({ type: 'error', user: username, action: 'Gagal login', details: result.message });
    } else {
      log({ type: 'login', user: username, action: 'Login berhasil' });
    }
  };

  const quickLogin = (user: string, pass: string) => {
    setUsername(user);
    setPassword(pass);
    const result = login(user, pass);
    if (result.success) log({ type: 'login', user, action: 'Login cepat berhasil' });
  };

  const bgStyle = theme.backgroundImage
    ? { backgroundImage: `url(${theme.backgroundImage})`, backgroundSize: 'cover', backgroundPosition: 'center' }
    : {};

  return (
    <div className="min-h-screen flex items-center justify-center p-6 relative overflow-hidden" style={bgStyle}>
      {!theme.backgroundImage && (
        <div className="absolute inset-0 bg-gradient-to-br from-red-950 via-orange-950 to-red-900" />
      )}
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" />

      <div className="relative z-10 w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-6">
          <div className="w-24 h-24 mx-auto rounded-3xl bg-gradient-to-br from-red-500 via-orange-500 to-amber-400 flex items-center justify-center text-5xl shadow-2xl shadow-red-500/50 mb-3 border-4 border-white/20">
            {profile.logo ? <img src={profile.logo} alt="logo" className="w-full h-full rounded-3xl object-cover" /> : '🌶️'}
          </div>
          <h1 className="text-4xl font-black text-white tracking-tight">{profile.name}</h1>
          <p className="text-amber-300 font-bold text-sm">{profile.tagline}</p>
        </div>

        {/* Login Card */}
        <div className="bg-white/15 backdrop-blur-2xl rounded-3xl p-8 shadow-2xl border-2 border-white/20">
          <h2 className="text-2xl font-black text-white mb-1">🔐 Login</h2>
          <p className="text-amber-200/70 text-sm mb-6">Masuk ke sistem POS {profile.name}</p>

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="text-xs font-bold text-amber-200 block mb-1.5">Username</label>
              <input
                type="text"
                value={username}
                onChange={e => setUsername(e.target.value)}
                placeholder="Masukkan username"
                className="w-full px-4 py-3 bg-white/10 border-2 border-white/20 rounded-xl text-white placeholder:text-amber-200/40 focus:outline-none focus:border-amber-400 transition"
                required
              />
            </div>
            <div>
              <label className="text-xs font-bold text-amber-200 block mb-1.5">Password</label>
              <input
                type="password"
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="Masukkan password"
                className="w-full px-4 py-3 bg-white/10 border-2 border-white/20 rounded-xl text-white placeholder:text-amber-200/40 focus:outline-none focus:border-amber-400 transition"
                required
              />
            </div>

            {error && (
              <div className="bg-red-500/20 border border-red-500/40 text-red-200 px-4 py-2.5 rounded-xl text-sm font-semibold">
                ⚠️ {error}
              </div>
            )}

            <button type="submit" className="w-full py-3.5 bg-gradient-to-r from-red-500 via-orange-500 to-amber-500 text-white font-black rounded-xl shadow-xl shadow-red-500/50 hover:shadow-2xl hover:scale-[1.02] transition-all text-lg">
              🔥 MASUK
            </button>
          </form>

          {/* Quick Access */}
          <div className="mt-6 pt-5 border-t border-white/10">
            <button
              onClick={() => setShowQuickAccess(!showQuickAccess)}
              className="text-xs text-amber-300/70 hover:text-white font-bold w-full text-center"
            >
              {showQuickAccess ? '▼' : '▶'} Akses Cepat (Demo)
            </button>
            {showQuickAccess && (
              <div className="mt-3 space-y-2">
                {[
                  { u: 'admin', p: 'admin123', role: 'admin' as const },
                  { u: 'kasir', p: 'kasir123', role: 'cashier' as const },
                  { u: 'dapur', p: 'dapur123', role: 'kitchen' as const },
                  { u: 'keuangan', p: 'keu123', role: 'finance' as const },
                  { u: 'marketing', p: 'mark123', role: 'marketing' as const },
                ].map(q => (
                  <button
                    key={q.u}
                    onClick={() => quickLogin(q.u, q.p)}
                    className={`w-full flex items-center gap-3 p-2.5 bg-gradient-to-r ${roleDescriptions[q.role].color} hover:opacity-90 rounded-xl text-white transition shadow-lg`}
                  >
                    <div className="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center font-bold text-sm">
                      {q.u[0].toUpperCase()}
                    </div>
                    <div className="flex-1 text-left">
                      <div className="text-sm font-black">{roleDescriptions[q.role].title}</div>
                      <div className="text-[10px] opacity-80">{q.u} / {q.p}</div>
                    </div>
                    <span className="text-lg">→</span>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        <div className="text-center mt-4 text-xs text-amber-200/50">
          © {new Date().getFullYear()} {profile.name} • Sistem POS Terintegrasi
        </div>
      </div>
    </div>
  );
}
