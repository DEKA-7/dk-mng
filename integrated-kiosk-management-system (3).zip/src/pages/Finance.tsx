import { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { formatRupiah } from '../data/menuData';

export default function Finance() {
  const { orders, dailyStats } = useStore();
  const [period, setPeriod] = useState<'today' | 'week' | 'month'>('today');
  const [view, setView] = useState<'overview' | 'transactions' | 'reports'>('overview');

  const paidOrders = orders.filter(o => o.status !== 'cancelled');

  const itemSales: Record<string, { name: string; count: number; revenue: number; image: string }> = {};
  paidOrders.forEach(o => o.items.forEach(i => {
    const key = i.item.id;
    if (!itemSales[key]) itemSales[key] = { name: i.item.name, count: 0, revenue: 0, image: i.item.image };
    itemSales[key].count += i.qty;
    itemSales[key].revenue += i.qty * i.item.price;
  }));
  const topItems = Object.values(itemSales).sort((a, b) => b.revenue - a.revenue).slice(0, 5);

  const paymentBreakdown = {
    cash: paidOrders.filter(o => o.paymentMethod === 'cash').reduce((s, o) => s + o.total, 0),
    card: paidOrders.filter(o => o.paymentMethod === 'card').reduce((s, o) => s + o.total, 0),
    qris: paidOrders.filter(o => o.paymentMethod === 'qris').reduce((s, o) => s + o.total, 0),
  };
  const totalRevenue = paymentBreakdown.cash + paymentBreakdown.card + paymentBreakdown.qris;

  const hourlyData = [12, 18, 25, 32, 28, 45, 62, 78, 65, 52, 40, 35];

  const periodLabel = period === 'today' ? 'Hari Ini' : period === 'week' ? '7 Hari' : '30 Hari';

  return (
    <div className="p-8 space-y-6 bg-gradient-to-br from-red-950 via-slate-900 to-red-950 min-h-screen">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-black text-white">📈 Keuangan</h1>
          <p className="text-amber-300/70">Laporan pendapatan & analisa penjualan</p>
        </div>
        <div className="flex gap-2">
          <button onClick={() => setView('overview')} className={`px-4 py-2 rounded-xl text-sm font-bold ${view === 'overview' ? 'bg-gradient-to-r from-blue-500 to-indigo-600 text-white shadow-lg' : 'bg-white/10 text-amber-200/80 border border-white/10'}`}>Ringkasan</button>
          <button onClick={() => setView('transactions')} className={`px-4 py-2 rounded-xl text-sm font-bold ${view === 'transactions' ? 'bg-gradient-to-r from-blue-500 to-indigo-600 text-white shadow-lg' : 'bg-white/10 text-amber-200/80 border border-white/10'}`}>Transaksi</button>
          <button onClick={() => setView('reports')} className={`px-4 py-2 rounded-xl text-sm font-bold ${view === 'reports' ? 'bg-gradient-to-r from-blue-500 to-indigo-600 text-white shadow-lg' : 'bg-white/10 text-amber-200/80 border border-white/10'}`}>Laporan</button>
        </div>
      </div>

      <div className="flex gap-2">
        {(['today', 'week', 'month'] as const).map(p => (
          <button key={p} onClick={() => setPeriod(p)} className={`px-4 py-1.5 rounded-full text-sm font-bold ${period === p ? 'bg-gradient-to-r from-blue-500 to-indigo-600 text-white shadow-lg' : 'bg-white/10 text-amber-200/80 border border-white/10'}`}>
            {p === 'today' ? 'Hari Ini' : p === 'week' ? '7 Hari' : '30 Hari'}
          </button>
        ))}
      </div>

      {view === 'overview' && (
        <>
          <div className="grid grid-cols-4 gap-4">
            <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-5 border border-white/10">
              <div className="text-amber-300/70 text-sm">Total Pendapatan</div>
              <div className="text-3xl font-black text-white mt-1">{formatRupiah(dailyStats.revenue)}</div>
              <div className="text-xs text-emerald-400 mt-2">▲ 12.5% dari {periodLabel === 'Hari Ini' ? 'kemarin' : 'periode lalu'}</div>
            </div>
            <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-5 border border-white/10">
              <div className="text-amber-300/70 text-sm">Total Transaksi</div>
              <div className="text-3xl font-black text-white mt-1">{dailyStats.orders}</div>
              <div className="text-xs text-emerald-400 mt-2">▲ 8.2%</div>
            </div>
            <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-5 border border-white/10">
              <div className="text-amber-300/70 text-sm">Rata-rata Tiket</div>
              <div className="text-3xl font-black text-white mt-1">{formatRupiah(dailyStats.avgTicket)}</div>
              <div className="text-xs text-rose-400 mt-2">▼ 2.1%</div>
            </div>
            <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-5 border border-white/10">
              <div className="text-amber-300/70 text-sm">Item Terjual</div>
              <div className="text-3xl font-black text-white mt-1">{dailyStats.itemsSold}</div>
              <div className="text-xs text-emerald-400 mt-2">▲ 15.3%</div>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div className="col-span-2 bg-white/10 backdrop-blur-xl rounded-2xl p-6 border border-white/10">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-black text-white">Pendapatan per Jam</h3>
                <span className="text-xs text-amber-300/60">{periodLabel}</span>
              </div>
              <div className="flex items-end gap-2 h-52">
                {hourlyData.map((v, i) => (
                  <div key={i} className="flex-1 flex flex-col items-center gap-1">
                    <div className="w-full bg-gradient-to-t from-red-600 via-orange-500 to-amber-400 rounded-t-lg transition-all hover:opacity-80 shadow-lg" style={{ height: `${v}%` }} />
                    <div className="text-xs text-amber-300/60">{11 + i}:00</div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-6 border border-white/10">
              <h3 className="font-black text-white mb-4">Metode Pembayaran</h3>
              <div className="space-y-4">
                {[
                  { key: 'cash', label: 'Tunai', color: 'from-emerald-500 to-teal-500', val: paymentBreakdown.cash },
                  { key: 'card', label: 'Kartu', color: 'from-blue-500 to-indigo-500', val: paymentBreakdown.card },
                  { key: 'qris', label: 'QRIS', color: 'from-purple-500 to-pink-500', val: paymentBreakdown.qris },
                ].map(pm => {
                  const pct = totalRevenue > 0 ? (pm.val / totalRevenue) * 100 : 0;
                  return (
                    <div key={pm.key}>
                      <div className="flex justify-between text-sm mb-1">
                        <span className="font-bold text-white">{pm.label}</span>
                        <span className="font-black text-amber-300">{formatRupiah(pm.val)}</span>
                      </div>
                      <div className="h-2.5 bg-white/10 rounded-full overflow-hidden">
                        <div className={`h-full bg-gradient-to-r ${pm.color} rounded-full transition-all`} style={{ width: `${pct}%` }} />
                      </div>
                      <div className="text-xs text-amber-300/60 mt-1">{pct.toFixed(1)}%</div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-6 border border-white/10">
            <h3 className="font-black text-white mb-4">🌶️ Top 5 Produk Terlaris</h3>
            <div className="space-y-2">
              {topItems.map((item, idx) => (
                <div key={idx} className="flex items-center gap-4 p-3 bg-white/5 rounded-2xl border border-white/10">
                  <div className={`w-9 h-9 rounded-xl flex items-center justify-center font-black text-white text-sm ${idx === 0 ? 'bg-gradient-to-br from-amber-400 to-orange-500' : idx === 1 ? 'bg-slate-400' : idx === 2 ? 'bg-orange-400' : 'bg-slate-600'}`}>
                    {idx + 1}
                  </div>
                  <div className="text-3xl">{item.image}</div>
                  <div className="flex-1">
                    <div className="font-bold text-white">{item.name}</div>
                    <div className="text-xs text-amber-300/70">{item.count} porsi terjual</div>
                  </div>
                  <div className="text-right">
                    <div className="font-black text-amber-300">{formatRupiah(item.revenue)}</div>
                    <div className="text-xs text-amber-300/60">Pendapatan</div>
                  </div>
                </div>
              ))}
              {topItems.length === 0 && <div className="text-center py-8 text-amber-300/50">Belum ada data penjualan</div>}
            </div>
          </div>
        </>
      )}

      {view === 'transactions' && (
        <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-6 border border-white/10">
          <h3 className="font-black text-white mb-4">Semua Transaksi</h3>
          <table className="w-full text-sm">
            <thead className="text-amber-300/70 border-b border-white/10">
              <tr>
                <th className="text-left py-3 px-2">ID</th>
                <th className="text-left py-3 px-2">Waktu</th>
                <th className="text-left py-3 px-2">Tipe</th>
                <th className="text-left py-3 px-2">Pelanggan</th>
                <th className="text-left py-3 px-2">Item</th>
                <th className="text-left py-3 px-2">Pembayaran</th>
                <th className="text-right py-3 px-2">Total</th>
                <th className="text-left py-3 px-2">Status</th>
              </tr>
            </thead>
            <tbody>
              {orders.map(o => (
                <tr key={o.id} className="border-b border-white/5 hover:bg-white/5">
                  <td className="py-3 px-2 font-bold text-white">{o.id}</td>
                  <td className="py-3 px-2 text-amber-200/80">{new Date(o.createdAt).toLocaleTimeString('id-ID')}</td>
                  <td className="py-3 px-2">
                    <span className={`px-2 py-1 rounded-lg text-xs font-bold ${o.type === 'kiosk' ? 'bg-red-500/20 text-red-300' : 'bg-orange-500/20 text-orange-300'}`}>
                      {o.type}
                    </span>
                  </td>
                  <td className="py-3 px-2 text-white">{o.customerName}</td>
                  <td className="py-3 px-2 text-amber-200/80">{o.items.reduce((s, i) => s + i.qty, 0)} item</td>
                  <td className="py-3 px-2 uppercase text-amber-300">{o.paymentMethod}</td>
                  <td className="py-3 px-2 text-right font-black text-amber-300">{formatRupiah(o.total)}</td>
                  <td className="py-3 px-2">
                    <span className={`px-2 py-1 rounded-lg text-xs font-bold ${
                      o.status === 'served' ? 'bg-slate-500/20 text-slate-300' :
                      o.status === 'cancelled' ? 'bg-rose-500/20 text-rose-300' :
                      'bg-emerald-500/20 text-emerald-300'
                    }`}>{o.status}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {view === 'reports' && (
        <div className="grid grid-cols-2 gap-4">
          {[
            { title: '📊 Laporan Penjualan', desc: 'Laporan lengkap penjualan periode terpilih dengan detail per item, per jam, dan per metode pembayaran.', btn: 'Export PDF' },
            { title: '💰 Laporan Laba/Rugi', desc: 'Analisa keuntungan bersih dengan perhitungan COGS, operasional, dan overhead.', btn: 'Export Excel' },
            { title: '📈 Analisa Trend', desc: 'Tren penjualan harian, mingguan, bulanan dengan perbandingan period-to-period.', btn: 'Lihat Detail' },
            { title: '🏪 Performa Outlet', desc: 'Perbandingan performa antar outlet dan ranking terbaik.', btn: 'Lihat Detail' },
          ].map((r, i) => (
            <div key={i} className="bg-white/10 backdrop-blur-xl rounded-2xl p-6 border border-white/10">
              <h3 className="font-black text-white mb-2">{r.title}</h3>
              <p className="text-amber-300/70 text-sm mb-4">{r.desc}</p>
              <button className="w-full py-2.5 bg-gradient-to-r from-blue-500 to-indigo-600 text-white rounded-xl font-bold hover:shadow-xl hover:shadow-blue-500/30 transition">{r.btn}</button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
