import { useState, useRef } from 'react';
import { useAuth } from '../context/AuthContext';
import { useSettings } from '../context/SettingsContext';
import { useActivity } from '../context/ActivityContext';
import ImageCropper from '../components/ImageCropper';
import { User } from '../data/users';

export default function Settings() {
  const { profile, updateProfile, theme, updateTheme, compressImage } = useSettings();
  const { users, addUser, deleteUser, isAdmin, user: currentUser } = useAuth();
  const { log } = useActivity();
  const [tab, setTab] = useState<'profile' | 'appearance' | 'users' | 'activity'>('profile');
  const [cropImage, setCropImage] = useState<string | null>(null);
  const [cropTarget, setCropTarget] = useState<'logo' | 'background'>('logo');
  const [newUserForm, setNewUserForm] = useState({ username: '', password: '', name: '', role: 'cashier' as User['role'], avatar: '👤', outlet: 'Outlet Utama' });
  const fileInputRef = useRef<HTMLInputElement>(null);
  const bgInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>, target: 'logo' | 'background') => {
    const file = e.target.files?.[0];
    if (!file) return;

    const sizeMB = file.size / (1024 * 1024);
    let dataUrl: string;

    if (sizeMB > 1) {
      log({ type: 'settings', user: currentUser?.username || 'admin', action: `Kompresi gambar ${target}`, details: `Ukuran awal: ${sizeMB.toFixed(2)}MB` });
      dataUrl = await compressImage(file, 0.8);
    } else {
      const reader = new FileReader();
      dataUrl = await new Promise((resolve, reject) => {
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });
    }
    setCropTarget(target);
    setCropImage(dataUrl);
  };

  const handleCropConfirm = (cropped: string) => {
    if (cropTarget === 'logo') {
      updateProfile({ logo: cropped });
      log({ type: 'settings', user: currentUser?.username || 'admin', action: 'Update logo' });
    } else {
      updateTheme({ backgroundImage: cropped });
      log({ type: 'settings', user: currentUser?.username || 'admin', action: 'Update background' });
    }
    setCropImage(null);
  };

  const handleAddUser = () => {
    if (!newUserForm.username || !newUserForm.password || !newUserForm.name) return;
    addUser(newUserForm);
    log({ type: 'edit', user: currentUser?.username || 'admin', action: 'Tambah user', details: newUserForm.username });
    setNewUserForm({ username: '', password: '', name: '', role: 'cashier', avatar: '👤', outlet: 'Outlet Utama' });
  };

  return (
    <div className="p-8 space-y-6">
      <div>
        <h1 className="text-3xl font-black text-white">⚙️ Pengaturan</h1>
        <p className="text-amber-300/70 text-sm">Kelola profil usaha, tampilan, dan user sistem</p>
      </div>

      <div className="flex gap-2 flex-wrap">
        {[
          { id: 'profile', label: '🏪 Profil Usaha' },
          { id: 'appearance', label: '🎨 Tampilan' },
          { id: 'users', label: '👥 Manajemen User' },
          { id: 'activity', label: '📜 Aktivitas' },
        ].map(t => (
          <button key={t.id} onClick={() => setTab(t.id as any)} className={`px-5 py-2.5 rounded-xl font-bold text-sm ${tab === t.id ? 'bg-gradient-to-r from-red-500 to-orange-600 text-white shadow-lg' : 'bg-white/10 text-amber-200/80 border border-white/10 hover:bg-white/15'}`}>
            {t.label}
          </button>
        ))}
      </div>

      {tab === 'profile' && (
        <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-6 border border-white/10 space-y-5">
          <h3 className="text-lg font-black text-white">🏪 Profil Usaha</h3>
          <div className="grid grid-cols-2 gap-5">
            <div>
              <label className="text-xs font-bold text-amber-300 block mb-1.5">Logo Usaha</label>
              <div className="flex items-center gap-3">
                <div className="w-24 h-24 rounded-2xl bg-gradient-to-br from-red-500 to-orange-500 flex items-center justify-center text-4xl overflow-hidden border-2 border-white/20">
                  {profile.logo ? <img src={profile.logo} alt="logo" className="w-full h-full object-cover" /> : '🌶️'}
                </div>
                <div className="flex flex-col gap-2">
                  <button onClick={() => fileInputRef.current?.click()} className="px-4 py-2 bg-gradient-to-r from-red-500 to-orange-600 text-white text-xs font-bold rounded-lg shadow">
                    📷 Upload Logo
                  </button>
                  {profile.logo && (
                    <button onClick={() => { updateProfile({ logo: null }); log({ type: 'settings', user: currentUser?.username || 'admin', action: 'Hapus logo' }); }} className="px-4 py-2 bg-white/10 text-amber-200 text-xs font-bold rounded-lg">
                      🗑️ Hapus
                    </button>
                  )}
                </div>
                <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={e => handleFileSelect(e, 'logo')} />
              </div>
              <p className="text-[10px] text-amber-300/50 mt-2">Maks 1MB, otomatis dikompresi & dicrop</p>
            </div>

            <div className="space-y-3">
              <div>
                <label className="text-xs font-bold text-amber-300 block mb-1.5">Nama Usaha</label>
                <input value={profile.name} onChange={e => updateProfile({ name: e.target.value })} className="w-full px-4 py-2.5 bg-white/10 border border-white/20 rounded-xl text-white focus:outline-none focus:border-amber-400" />
              </div>
              <div>
                <label className="text-xs font-bold text-amber-300 block mb-1.5">Tagline / Slogan</label>
                <input value={profile.tagline} onChange={e => updateProfile({ tagline: e.target.value })} className="w-full px-4 py-2.5 bg-white/10 border border-white/20 rounded-xl text-white focus:outline-none focus:border-amber-400" />
              </div>
            </div>

            <div>
              <label className="text-xs font-bold text-amber-300 block mb-1.5">📞 No. Telepon</label>
              <input value={profile.phone} onChange={e => updateProfile({ phone: e.target.value })} className="w-full px-4 py-2.5 bg-white/10 border border-white/20 rounded-xl text-white focus:outline-none focus:border-amber-400" />
            </div>
            <div>
              <label className="text-xs font-bold text-amber-300 block mb-1.5">💬 WhatsApp</label>
              <input value={profile.whatsapp} onChange={e => updateProfile({ whatsapp: e.target.value })} className="w-full px-4 py-2.5 bg-white/10 border border-white/20 rounded-xl text-white focus:outline-none focus:border-amber-400" />
            </div>
            <div className="col-span-2">
              <label className="text-xs font-bold text-amber-300 block mb-1.5">📍 Alamat</label>
              <input value={profile.address} onChange={e => updateProfile({ address: e.target.value })} className="w-full px-4 py-2.5 bg-white/10 border border-white/20 rounded-xl text-white focus:outline-none focus:border-amber-400" />
            </div>
            <div>
              <label className="text-xs font-bold text-amber-300 block mb-1.5">💱 Mata Uang</label>
              <input value={profile.currency} onChange={e => updateProfile({ currency: e.target.value })} className="w-full px-4 py-2.5 bg-white/10 border border-white/20 rounded-xl text-white focus:outline-none focus:border-amber-400" />
            </div>
          </div>
        </div>
      )}

      {tab === 'appearance' && (
        <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-6 border border-white/10 space-y-5">
          <h3 className="text-lg font-black text-white">🎨 Tampilan & Tema</h3>

          <div>
            <label className="text-xs font-bold text-amber-300 block mb-1.5">Background Gambar</label>
            <div className="flex items-center gap-3">
              <div className="w-32 h-20 rounded-xl bg-slate-800 overflow-hidden border-2 border-white/20">
                {theme.backgroundImage ? <img src={theme.backgroundImage} alt="bg" className="w-full h-full object-cover" /> : <div className="w-full h-full bg-gradient-to-br from-red-950 to-orange-950" />}
              </div>
              <div className="flex flex-col gap-2">
                <button onClick={() => bgInputRef.current?.click()} className="px-4 py-2 bg-gradient-to-r from-red-500 to-orange-600 text-white text-xs font-bold rounded-lg shadow">
                  📷 Upload Background
                </button>
                {theme.backgroundImage && (
                  <button onClick={() => { updateTheme({ backgroundImage: null }); log({ type: 'settings', user: currentUser?.username || 'admin', action: 'Hapus background' }); }} className="px-4 py-2 bg-white/10 text-amber-200 text-xs font-bold rounded-lg">
                    🗑️ Hapus
                  </button>
                )}
              </div>
              <input ref={bgInputRef} type="file" accept="image/*" className="hidden" onChange={e => handleFileSelect(e, 'background')} />
            </div>
            <p className="text-[10px] text-amber-300/50 mt-2">Maks 1MB, akan dikompresi otomatis jika besar</p>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-bold text-amber-300 block mb-1.5">Warna Dasar</label>
              <input type="color" value={theme.backgroundColor} onChange={e => updateTheme({ backgroundColor: e.target.value })} className="w-full h-12 bg-white/10 border border-white/20 rounded-xl cursor-pointer" />
            </div>
            <div>
              <label className="text-xs font-bold text-amber-300 block mb-1.5">Warna Aksen</label>
              <input type="color" value={theme.accentColor} onChange={e => updateTheme({ accentColor: e.target.value })} className="w-full h-12 bg-white/10 border border-white/20 rounded-xl cursor-pointer" />
            </div>
          </div>

          <div>
            <label className="text-xs font-bold text-amber-300 block mb-2">Mode Tema</label>
            <div className="flex gap-2">
              {(['dark', 'light', 'custom'] as const).map(m => (
                <button key={m} onClick={() => updateTheme({ themeMode: m })} className={`px-5 py-2 rounded-xl font-bold text-sm ${theme.themeMode === m ? 'bg-gradient-to-r from-red-500 to-orange-600 text-white' : 'bg-white/10 text-amber-200/80 border border-white/10'}`}>
                  {m === 'dark' ? '🌙 Dark' : m === 'light' ? '☀️ Light' : '🎨 Custom'}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {tab === 'users' && (
        <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-6 border border-white/10 space-y-5">
          <h3 className="text-lg font-black text-white">👥 Manajemen User</h3>

          {isAdmin && (
            <div className="bg-white/5 rounded-2xl p-5 border border-amber-400/30">
              <h4 className="font-bold text-amber-300 mb-3">➕ Tambah User Baru</h4>
              <div className="grid grid-cols-4 gap-3">
                <input placeholder="Username" value={newUserForm.username} onChange={e => setNewUserForm({ ...newUserForm, username: e.target.value })} className="px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white text-sm" />
                <input placeholder="Password" value={newUserForm.password} onChange={e => setNewUserForm({ ...newUserForm, password: e.target.value })} className="px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white text-sm" />
                <input placeholder="Nama Lengkap" value={newUserForm.name} onChange={e => setNewUserForm({ ...newUserForm, name: e.target.value })} className="px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white text-sm" />
                <select value={newUserForm.role} onChange={e => setNewUserForm({ ...newUserForm, role: e.target.value as User['role'] })} className="px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white text-sm">
                  <option value="cashier">💰 Kasir</option>
                  <option value="kitchen">🍳 Dapur</option>
                  <option value="finance">📈 Keuangan</option>
                  <option value="marketing">🎯 Marketing</option>
                  <option value="admin">👑 Admin</option>
                </select>
              </div>
              <button onClick={handleAddUser} className="mt-3 px-5 py-2 bg-gradient-to-r from-red-500 to-orange-600 text-white font-bold rounded-lg text-sm shadow">
                ➕ Tambah User
              </button>
            </div>
          )}

          <div className="space-y-2">
            {users.map(u => (
              <div key={u.username} className="flex items-center gap-4 p-4 bg-white/5 rounded-xl border border-white/10">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-red-500 to-orange-500 flex items-center justify-center text-2xl">{u.avatar}</div>
                <div className="flex-1">
                  <div className="font-bold text-white">{u.name}</div>
                  <div className="text-xs text-amber-300/70">@{u.username} • {u.role} • {u.outlet}</div>
                </div>
                {isAdmin && u.username !== 'admin' && (
                  <button onClick={() => { deleteUser(u.username); log({ type: 'edit', user: currentUser?.username || 'admin', action: 'Hapus user', details: u.username }); }} className="px-3 py-1.5 bg-red-500/20 hover:bg-red-500/40 text-red-300 text-xs font-bold rounded-lg">
                    🗑️ Hapus
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {tab === 'activity' && (
        <ActivityLog />
      )}

      {cropImage && (
        <ImageCropper imageSrc={cropImage} aspectRatio={cropTarget === 'logo' ? 1 : 16 / 9} onCancel={() => setCropImage(null)} onConfirm={handleCropConfirm} />
      )}
    </div>
  );
}

function ActivityLog() {
  const { activities, clear, exportCSV } = useActivity();
  const { currentUser } = useAuth() as any;
  const { log } = useActivity();

  return (
    <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-6 border border-white/10">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-black text-white">📜 Realtime Activity Manifest</h3>
        <div className="flex gap-2">
          <button onClick={() => {
            const csv = exportCSV();
            const blob = new Blob([csv], { type: 'text/csv' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `activity-${new Date().toISOString().slice(0, 10)}.csv`;
            a.click();
          }} className="px-4 py-2 bg-blue-500/20 hover:bg-blue-500/40 text-blue-300 text-xs font-bold rounded-lg border border-blue-400/30">
            📥 Export CSV
          </button>
          <button onClick={() => { clear(); log({ type: 'settings', user: currentUser?.username || 'admin', action: 'Clear activity log' }); }} className="px-4 py-2 bg-red-500/20 hover:bg-red-500/40 text-red-300 text-xs font-bold rounded-lg border border-red-400/30">
            🗑️ Bersihkan
          </button>
        </div>
      </div>

      <div className="max-h-[500px] overflow-y-auto space-y-2">
        {activities.length === 0 ? (
          <div className="text-center py-12 text-amber-300/50">Belum ada aktivitas</div>
        ) : (
          activities.map(a => (
            <div key={a.id} className="flex items-center gap-3 p-3 bg-white/5 rounded-xl border border-white/5">
              <div className={`w-10 h-10 rounded-lg flex items-center justify-center text-lg ${
                a.type === 'login' ? 'bg-emerald-500/20 text-emerald-300' :
                a.type === 'order' ? 'bg-red-500/20 text-red-300' :
                a.type === 'payment' ? 'bg-amber-500/20 text-amber-300' :
                a.type === 'edit' ? 'bg-purple-500/20 text-purple-300' :
                a.type === 'error' ? 'bg-rose-500/20 text-rose-300' :
                'bg-blue-500/20 text-blue-300'
              }`}>
                {a.type === 'login' ? '🔐' : a.type === 'order' ? '📦' : a.type === 'payment' ? '💰' : a.type === 'edit' ? '✏️' : a.type === 'error' ? '⚠️' : '📋'}
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-bold text-white text-sm">{a.action}</div>
                <div className="text-xs text-amber-300/60">@{a.user} • {a.details || ''}</div>
              </div>
              <div className="text-xs text-amber-300/50 text-right whitespace-nowrap">
                {new Date(a.timestamp).toLocaleTimeString('id-ID')}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
