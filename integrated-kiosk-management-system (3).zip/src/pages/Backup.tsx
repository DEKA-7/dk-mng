import { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useActivity } from '../context/ActivityContext';

interface GDriveAuth { email: string; token: string; connected: boolean; }

const STORAGE_KEYS = [
  'seblakidr_orders', 'seblakidr_menu', 'seblakidr_users', 'seblakidr_auth',
  'seblakidr_profile', 'seblakidr_theme', 'seblakidr_activities',
];

export default function Backup() {
  const { user } = useAuth();
  const { log } = useActivity();
  const [gdrive, setGdrive] = useState<GDriveAuth>(() => {
    const s = localStorage.getItem('seblakidr_gdrive');
    return s ? JSON.parse(s) : { email: '', token: '', connected: false };
  });
  const [emailInput, setEmailInput] = useState('');
  const [tokenInput, setTokenInput] = useState('');
  const [message, setMessage] = useState('');
  const [lastBackup, setLastBackup] = useState<string | null>(
    localStorage.getItem('seblakidr_last_backup')
  );
  const [backups, setBackups] = useState<{ name: string; date: string; size: number }[]>(() => {
    const s = localStorage.getItem('seblakidr_backups_list');
    return s ? JSON.parse(s) : [];
  });

  const collectData = () => {
    const data: Record<string, any> = {};
    STORAGE_KEYS.forEach(k => {
      const v = localStorage.getItem(k);
      if (v) data[k] = v;
    });
    data._meta = {
      exportedAt: new Date().toISOString(),
      version: '1.0.0',
      app: 'SeblakIDR POS',
      exportedBy: user?.username || 'unknown',
    };
    return data;
  };

  const handleConnect = () => {
    if (!emailInput || !tokenInput) {
      setMessage('⚠️ Email dan token Google API wajib diisi');
      return;
    }
    const newAuth = { email: emailInput, token: tokenInput, connected: true };
    setGdrive(newAuth);
    localStorage.setItem('seblakidr_gdrive', JSON.stringify(newAuth));
    log({ type: 'backup', user: user?.username || 'admin', action: 'Connect Google Drive', details: emailInput });
    setMessage('✓ Berhasil terhubung ke Google Drive');
    setTimeout(() => setMessage(''), 3000);
  };

  const handleDisconnect = () => {
    setGdrive({ email: '', token: '', connected: false });
    localStorage.removeItem('seblakidr_gdrive');
    setMessage('✓ Terputus dari Google Drive');
    setTimeout(() => setMessage(''), 3000);
  };

  const handleBackup = () => {
    const data = collectData();
    const json = JSON.stringify(data, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const sizeKB = Math.round(blob.size / 1024);
    const name = `backup-seblakidr-${new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-')}.json`;

    // Download locally
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = name;
    a.click();
    URL.revokeObjectURL(url);

    const newBackup = { name, date: new Date().toLocaleString('id-ID'), size: sizeKB };
    const newList = [newBackup, ...backups].slice(0, 20);
    setBackups(newList);
    localStorage.setItem('seblakidr_backups_list', JSON.stringify(newList));
    localStorage.setItem('seblakidr_last_backup', new Date().toISOString());
    setLastBackup(new Date().toISOString());
    log({ type: 'backup', user: user?.username || 'admin', action: 'Backup data', details: `${name} (${sizeKB}KB)` });
    setMessage(`✓ Backup berhasil: ${name} (${sizeKB} KB)`);
    setTimeout(() => setMessage(''), 4000);
  };

  const handleRestore = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const data = JSON.parse(reader.result as string);
        let restored = 0;
        Object.keys(data).forEach(key => {
          if (key !== '_meta' && typeof data[key] === 'string') {
            localStorage.setItem(key, data[key]);
            restored++;
          }
        });
        log({ type: 'backup', user: user?.username || 'admin', action: 'Restore data', details: `${restored} key dipulihkan` });
        setMessage(`✓ Restore berhasil! ${restored} data dipulihkan. Refresh halaman untuk melihat perubahan.`);
        setTimeout(() => {
          setMessage('');
          window.location.reload();
        }, 3000);
      } catch (err) {
        setMessage('❌ File backup tidak valid');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="p-8 space-y-6">
      <div>
        <h1 className="text-3xl font-black text-white">💾 Backup & Restore</h1>
        <p className="text-amber-300/70 text-sm">Kelola backup data ke Google Drive atau file lokal</p>
      </div>

      {message && (
        <div className="bg-emerald-500/20 border border-emerald-400/40 text-emerald-200 px-5 py-3 rounded-xl font-semibold">
          {message}
        </div>
      )}

      {/* Google Drive Section */}
      <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-6 border border-white/10">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-lg font-black text-white">☁️ Google Drive Integration</h3>
            <p className="text-amber-300/70 text-sm">Simpan backup otomatis ke Google Drive Anda</p>
          </div>
          <div className={`px-3 py-1 rounded-full text-xs font-bold ${gdrive.connected ? 'bg-emerald-500/20 text-emerald-300' : 'bg-slate-500/20 text-slate-300'}`}>
            {gdrive.connected ? '● Terhubung' : '○ Belum Terhubung'}
          </div>
        </div>

        {!gdrive.connected ? (
          <div className="space-y-3">
            <div className="bg-blue-500/10 border border-blue-400/30 rounded-xl p-4">
              <p className="text-sm text-blue-200">
                📌 Cara mendapatkan Google API Token:
                <br />1. Buka <a href="https://console.cloud.google.com" target="_blank" className="underline text-blue-300">Google Cloud Console</a>
                <br />2. Buat project & aktifkan Google Drive API
                <br />3. Buat OAuth 2.0 credential & copy token
              </p>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <input
                type="email"
                placeholder="Email Google Drive"
                value={emailInput}
                onChange={e => setEmailInput(e.target.value)}
                className="px-4 py-2.5 bg-white/10 border border-white/20 rounded-xl text-white placeholder:text-amber-200/40 focus:outline-none focus:border-amber-400"
              />
              <input
                type="password"
                placeholder="Google API Token"
                value={tokenInput}
                onChange={e => setTokenInput(e.target.value)}
                className="px-4 py-2.5 bg-white/10 border border-white/20 rounded-xl text-white placeholder:text-amber-200/40 focus:outline-none focus:border-amber-400"
              />
            </div>
            <button onClick={handleConnect} className="px-5 py-2.5 bg-gradient-to-r from-blue-500 to-indigo-600 text-white font-bold rounded-xl shadow-lg hover:shadow-xl">
              🔗 Hubungkan ke Google Drive
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            <div className="flex items-center gap-3 p-3 bg-emerald-500/10 border border-emerald-400/30 rounded-xl">
              <div className="w-10 h-10 rounded-full bg-emerald-500/30 flex items-center justify-center text-xl">📧</div>
              <div className="flex-1">
                <div className="font-bold text-white">{gdrive.email}</div>
                <div className="text-xs text-emerald-300">Token: {gdrive.token.slice(0, 12)}***</div>
              </div>
              <button onClick={handleDisconnect} className="px-3 py-1.5 bg-rose-500/20 hover:bg-rose-500/40 text-rose-300 text-xs font-bold rounded-lg">
                Putuskan
              </button>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <button onClick={handleBackup} className="py-3 bg-gradient-to-r from-emerald-500 to-teal-600 text-white font-bold rounded-xl shadow-lg hover:shadow-xl">
                ☁️ Backup ke Drive
              </button>
              <label className="py-3 bg-gradient-to-r from-blue-500 to-indigo-600 text-white font-bold rounded-xl shadow-lg hover:shadow-xl text-center cursor-pointer">
                📥 Restore dari Drive
                <input type="file" accept=".json" className="hidden" onChange={handleRestore} />
              </label>
              <button onClick={handleBackup} className="py-3 bg-gradient-to-r from-purple-500 to-pink-600 text-white font-bold rounded-xl shadow-lg hover:shadow-xl">
                ⏰ Backup Otomatis (Harian)
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Local Backup */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-6 border border-white/10">
          <h3 className="text-lg font-black text-white mb-2">💾 Backup Lokal</h3>
          <p className="text-amber-300/70 text-sm mb-4">Unduh semua data sebagai file JSON</p>
          <button onClick={handleBackup} className="w-full py-3 bg-gradient-to-r from-red-500 to-orange-600 text-white font-bold rounded-xl shadow-lg hover:shadow-xl">
            📥 Download Backup
          </button>
          {lastBackup && (
            <p className="text-xs text-amber-300/70 mt-3 text-center">
              Backup terakhir: {new Date(lastBackup).toLocaleString('id-ID')}
            </p>
          )}
        </div>

        <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-6 border border-white/10">
          <h3 className="text-lg font-black text-white mb-2">📤 Restore Data</h3>
          <p className="text-amber-300/70 text-sm mb-4">Upload file backup untuk memulihkan data</p>
          <label className="block w-full py-3 bg-gradient-to-r from-blue-500 to-indigo-600 text-white font-bold rounded-xl shadow-lg hover:shadow-xl text-center cursor-pointer">
            📂 Pilih File Backup
            <input type="file" accept=".json" className="hidden" onChange={handleRestore} />
          </label>
          <p className="text-xs text-rose-300/70 mt-3 text-center">
            ⚠️ Restore akan menimpa semua data yang ada
          </p>
        </div>
      </div>

      {/* Backup History */}
      <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-6 border border-white/10">
        <h3 className="text-lg font-black text-white mb-4">📜 Riwayat Backup ({backups.length})</h3>
        {backups.length === 0 ? (
          <div className="text-center py-8 text-amber-300/50">Belum ada backup</div>
        ) : (
          <div className="space-y-2 max-h-64 overflow-y-auto">
            {backups.map((b, i) => (
              <div key={i} className="flex items-center justify-between p-3 bg-white/5 rounded-xl border border-white/10">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-red-500 to-orange-600 flex items-center justify-center text-lg">💾</div>
                  <div>
                    <div className="font-bold text-white text-sm">{b.name}</div>
                    <div className="text-xs text-amber-300/70">{b.date} • {b.size} KB</div>
                  </div>
                </div>
                <button className="px-3 py-1.5 bg-white/10 hover:bg-white/20 text-amber-200 text-xs font-bold rounded-lg">
                  Download
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
