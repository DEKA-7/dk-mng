import { useStore } from '../context/StoreContext';
import { formatRupiah } from '../data/menuData';

type Page = 'dashboard' | 'kiosk' | 'cashier' | 'kitchen' | 'finance' | 'marketing';

export default function Dashboard({ onNavigate, visibleNav }: { onNavigate: (p: Page) => void; visibleNav?: string[] }) {
  const { orders, dailyStats } = useStore();
  const activeOrders = orders.filter(o => o.status !== 'served' && o.status !== 'cancelled');

  const modules = [
    { id: 'kiosk' as Page, title: 'Self-Order Kiosk', desc: 'Sistem pemesanan mandiri untuk pelanggan', icon: '🖥️', color: 'from-red-500 to-orange-600', stat: `${dailyStats.kioskOrders} pesanan` },
    { id: 'cashier' as Page, title: 'Kasir POS', desc: 'Transaksi counter dan pembayaran', icon: '💰', color: 'from-orange-500 to-red-600', stat: `${dailyStats.cashierOrders} transaksi` },
    { id: 'kitchen' as Page, title: 'Dapur', desc: 'Manajemen pesanan real-time untuk tim dapur', icon: '🍳', color: 'from-emerald-500 to-teal-600', stat: `${activeOrders.length} aktif` },
    { id: 'finance' as Page, title: 'Keuangan', desc: 'Laporan pendapatan & analisa penjualan', icon: '📈', color: 'from-blue-500 to-indigo-600', stat: formatRupiah(dailyStats.revenue) },
    { id: 'marketing' as Page, title: 'Pemasaran', desc: 'Kelola promo, kupon, & engagement', icon: '🎯', color: 'from-purple-500 to-pink-600', stat: '5 promosi aktif' },
  ];

  const recentOrders = orders.slice(0, 6);

  return (
    <div className="p-8 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <div className="inline-flex items-center gap-2 bg-red-500/20 border border-red-500/40 text-amber-300 text-xs px-3 py-1 rounded-full mb-2">
            🌶️ PEDASNYA NAMPOL, RASANYA NAGIH!
          </div>
          <h1 className="text-3xl font-black text-white tracking-tight">Dashboard SeblakIDR</h1>
          <p className="text-amber-200/70 mt-1">Sistem terintegrasi warung seblak</p>
        </div>
        <div className="text-right">
          <div className="text-xs text-amber-300/70">Hari ini</div>
          <div className="font-bold text-white">{new Date().toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}</div>
        </div>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-4 gap-4">
        <div className="bg-gradient-to-br from-red-600/30 to-red-800/30 backdrop-blur-xl rounded-2xl p-5 border border-red-500/30">
          <div className="flex items-center justify-between mb-2">
            <span className="text-amber-200/80 text-sm">Total Pendapatan</span>
            <span className="text-2xl">💰</span>
          </div>
          <div className="text-2xl font-black text-white">{formatRupiah(dailyStats.revenue)}</div>
          <div className="text-xs text-emerald-400 mt-1">▲ 12.5% dari kemarin</div>
        </div>
        <div className="bg-gradient-to-br from-orange-600/30 to-amber-700/30 backdrop-blur-xl rounded-2xl p-5 border border-orange-500/30">
          <div className="flex items-center justify-between mb-2">
            <span className="text-amber-200/80 text-sm">Total Pesanan</span>
            <span className="text-2xl">📦</span>
          </div>
          <div className="text-2xl font-black text-white">{dailyStats.orders}</div>
          <div className="text-xs text-emerald-400 mt-1">▲ 8.2%</div>
        </div>
        <div className="bg-gradient-to-br from-yellow-600/30 to-amber-700/30 backdrop-blur-xl rounded-2xl p-5 border border-yellow-500/30">
          <div className="flex items-center justify-between mb-2">
            <span className="text-amber-200/80 text-sm">Item Terjual</span>
            <span className="text-2xl">🍜</span>
          </div>
          <div className="text-2xl font-black text-white">{dailyStats.itemsSold}</div>
          <div className="text-xs text-emerald-400 mt-1">▲ 15.3%</div>
        </div>
        <div className="bg-gradient-to-br from-pink-600/30 to-red-700/30 backdrop-blur-xl rounded-2xl p-5 border border-pink-500/30">
          <div className="flex items-center justify-between mb-2">
            <span className="text-amber-200/80 text-sm">Rata-rata Tiket</span>
            <span className="text-2xl">🎟️</span>
          </div>
          <div className="text-2xl font-black text-white">{formatRupiah(dailyStats.avgTicket)}</div>
          <div className="text-xs text-rose-400 mt-1">▼ 2.1%</div>
        </div>
      </div>

      {/* Module Cards */}
      <div>
        <h2 className="text-xl font-black text-white mb-4">Modul Sistem 🌶️</h2>
        <div className="grid grid-cols-3 gap-4">
          {modules.filter(m => !visibleNav || visibleNav.includes(m.id)).map(m => (
            <button
              key={m.id}
              onClick={() => onNavigate(m.id)}
              className={`group text-left bg-gradient-to-br ${m.color} rounded-2xl p-6 text-white shadow-xl shadow-red-900/50 hover:shadow-2xl transition-all hover:-translate-y-1 hover:scale-[1.02]`}
            >
              <div className="text-4xl mb-3">{m.icon}</div>
              <div className="text-lg font-black">{m.title}</div>
              <div className="text-sm text-white/80 mt-1 mb-4">{m.desc}</div>
              <div className="flex items-center justify-between">
                <span className="text-xs bg-white/20 backdrop-blur px-3 py-1 rounded-full font-bold">{m.stat}</span>
                <span className="text-lg group-hover:translate-x-1 transition-transform">→</span>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Recent Orders + Quick Actions */}
      <div className="grid grid-cols-3 gap-4">
        <div className="col-span-2 bg-white/10 backdrop-blur-xl rounded-2xl p-6 border border-red-500/20">
          <h3 className="font-black text-white mb-4 text-lg">🔥 Pesanan Terbaru</h3>
          <div className="space-y-2">
            {recentOrders.map(o => (
              <div key={o.id} className="flex items-center justify-between py-3 px-4 bg-white/5 hover:bg-white/10 rounded-xl border border-white/10 transition">
                <div className="flex items-center gap-3">
                  <div className={`w-11 h-11 rounded-xl flex items-center justify-center text-xl ${o.type === 'kiosk' ? 'bg-red-500/30 text-red-300' : 'bg-orange-500/30 text-orange-300'}`}>
                    {o.type === 'kiosk' ? '🖥️' : '💰'}
                  </div>
                  <div>
                    <div className="font-bold text-white">{o.id}</div>
                    <div className="text-xs text-amber-300/70">{o.items.reduce((s, i) => s + i.qty, 0)} item • {o.customerName || 'N/A'}</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-black text-amber-300">{formatRupiah(o.total)}</div>
                  <span className={`text-xs px-2 py-1 rounded-full font-bold ${
                    o.status === 'ready' ? 'bg-emerald-500/30 text-emerald-300' :
                    o.status === 'preparing' ? 'bg-amber-500/30 text-amber-300' :
                    o.status === 'served' ? 'bg-slate-500/30 text-slate-300' :
                    o.status === 'cancelled' ? 'bg-rose-500/30 text-rose-300' :
                    'bg-blue-500/30 text-blue-300'
                  }`}>{o.status}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
        <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-6 border border-red-500/20">
          <h3 className="font-black text-white mb-4 text-lg">⚡ Aksi Cepat</h3>
          <div className="space-y-2">
            <button onClick={() => onNavigate('kiosk')} className="w-full flex items-center gap-3 p-3 bg-red-500/20 hover:bg-red-500/30 rounded-xl text-left transition border border-red-500/30">
              <span className="text-2xl">🖥️</span>
              <div>
                <div className="font-bold text-white text-sm">Buka Kiosk</div>
                <div className="text-xs text-amber-300/70">Mode pelanggan</div>
              </div>
            </button>
            <button onClick={() => onNavigate('cashier')} className="w-full flex items-center gap-3 p-3 bg-orange-500/20 hover:bg-orange-500/30 rounded-xl text-left transition border border-orange-500/30">
              <span className="text-2xl">💰</span>
              <div>
                <div className="font-bold text-white text-sm">Transaksi Baru</div>
                <div className="text-xs text-amber-300/70">Kasir counter</div>
              </div>
            </button>
            <button onClick={() => onNavigate('kitchen')} className="w-full flex items-center gap-3 p-3 bg-emerald-500/20 hover:bg-emerald-500/30 rounded-xl text-left transition border border-emerald-500/30">
              <span className="text-2xl">🍳</span>
              <div>
                <div className="font-bold text-white text-sm">Display Dapur</div>
                <div className="text-xs text-amber-300/70">Pesanan aktif</div>
              </div>
            </button>
            <button onClick={() => onNavigate('finance')} className="w-full flex items-center gap-3 p-3 bg-blue-500/20 hover:bg-blue-500/30 rounded-xl text-left transition border border-blue-500/30">
              <span className="text-2xl">📊</span>
              <div>
                <div className="font-bold text-white text-sm">Laporan Harian</div>
                <div className="text-xs text-amber-300/70">Export & analisa</div>
              </div>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
