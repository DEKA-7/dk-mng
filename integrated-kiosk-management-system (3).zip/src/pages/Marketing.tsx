import { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { formatRupiah } from '../data/menuData';

interface Promotion {
  id: string;
  title: string;
  description: string;
  discount: string;
  type: 'percentage' | 'fixed' | 'bogo';
  target: string;
  startDate: string;
  endDate: string;
  status: 'active' | 'scheduled' | 'ended';
  color: string;
}

const initialPromotions: Promotion[] = [
  { id: 'P001', title: 'Bucket Hemat Weekend', description: 'Diskon 20% untuk semua bucket di hari Sabtu & Minggu', discount: '20%', type: 'percentage', target: 'Semua Bucket', startDate: '2025-01-01', endDate: '2025-12-31', status: 'active', color: 'from-red-500 to-orange-600' },
  { id: 'P002', title: 'Beli 1 Gratis 1 Seblak', description: 'Beli 1 seblak gratis 1 setiap hari Jumat pedas', discount: 'B1G1', type: 'bogo', target: 'Seblak Original', startDate: '2025-01-10', endDate: '2025-03-31', status: 'active', color: 'from-purple-500 to-pink-600' },
  { id: 'P003', title: 'Diskon Spesial QRIS 10%', description: 'Diskon 10% untuk pembayaran via QRIS semua e-wallet', discount: '10%', type: 'percentage', target: 'Semua Menu', startDate: '2025-01-01', endDate: '2025-06-30', status: 'active', color: 'from-blue-500 to-indigo-600' },
  { id: 'P004', title: 'Paket Ramadhan Pedas', description: 'Paket spesial Ramadhan: 3 Seblak + Es Teh gratis', discount: 'Rp 15K', type: 'fixed', target: 'Seblak Komplit', startDate: '2025-03-01', endDate: '2025-04-30', status: 'scheduled', color: 'from-emerald-500 to-teal-600' },
  { id: 'P005', title: 'Promo Pelajar', description: 'Diskon 15% dengan menunjukkan kartu pelajar', discount: '15%', type: 'percentage', target: 'Semua Menu', startDate: '2024-09-01', endDate: '2024-12-31', status: 'ended', color: 'from-slate-400 to-slate-500' },
];

export default function Marketing() {
  const [promotions, setPromotions] = useState<Promotion[]>(initialPromotions);
  const [showCreate, setShowCreate] = useState(false);
  const { orders, dailyStats } = useStore();

  const toggleStatus = (id: string) => {
    setPromotions(prev => prev.map(p => p.id === id ? { ...p, status: p.status === 'active' ? 'ended' : 'active' } : p));
  };

  const activePromos = promotions.filter(p => p.status === 'active').length;
  const kioskPct = dailyStats.orders ? (dailyStats.kioskOrders / dailyStats.orders) * 100 : 0;
  const totalOrders = orders.filter(o => o.status !== 'cancelled').length;
  const avgOrder = dailyStats.avgTicket;

  return (
    <div className="p-8 space-y-6 bg-gradient-to-br from-red-950 via-purple-950 to-red-950 min-h-screen">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-black text-white">🎯 Pemasaran</h1>
          <p className="text-amber-300/70">Kelola promosi, kupon, dan engagement pelanggan</p>
        </div>
        <button onClick={() => setShowCreate(true)} className="px-5 py-2.5 bg-gradient-to-r from-purple-500 to-pink-600 text-white rounded-xl font-bold shadow-xl hover:shadow-2xl hover:scale-105 transition">
          + Buat Promosi Baru
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-4">
        <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-5 border border-white/10">
          <div className="text-amber-300/70 text-sm">Promosi Aktif</div>
          <div className="text-3xl font-black text-purple-300 mt-1">{activePromos}</div>
          <div className="text-xs text-amber-300/60 mt-2">dari {promotions.length} total</div>
        </div>
        <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-5 border border-white/10">
          <div className="text-amber-300/70 text-sm">Kupon Terpakai</div>
          <div className="text-3xl font-black text-pink-300 mt-1">142</div>
          <div className="text-xs text-emerald-400 mt-2">▲ 23% bulan ini</div>
        </div>
        <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-5 border border-white/10">
          <div className="text-amber-300/70 text-sm">Customer Retention</div>
          <div className="text-3xl font-black text-purple-300 mt-1">68%</div>
          <div className="text-xs text-emerald-400 mt-2">▲ 5.2%</div>
        </div>
        <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-5 border border-white/10">
          <div className="text-amber-300/70 text-sm">Avg Order Value</div>
          <div className="text-3xl font-black text-pink-300 mt-1">{formatRupiah(avgOrder)}</div>
          <div className="text-xs text-amber-300/60 mt-2">{totalOrders} transaksi</div>
        </div>
      </div>

      {/* Channel performance */}
      <div className="grid grid-cols-3 gap-4">
        <div className="col-span-2 bg-white/10 backdrop-blur-xl rounded-2xl p-6 border border-white/10">
          <h3 className="font-black text-white mb-4">📊 Performa Channel Pemesanan</h3>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="font-bold text-white">🖥️ Self-Order Kiosk</span>
                <span className="font-black text-red-300">{dailyStats.kioskOrders} pesanan ({kioskPct.toFixed(0)}%)</span>
              </div>
              <div className="h-3 bg-white/10 rounded-full overflow-hidden">
                <div className="h-full bg-gradient-to-r from-red-500 to-orange-500 rounded-full shadow-lg" style={{ width: `${kioskPct}%` }} />
              </div>
            </div>
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="font-bold text-white">💰 Kasir Counter</span>
                <span className="font-black text-orange-300">{dailyStats.cashierOrders} pesanan ({(100 - kioskPct).toFixed(0)}%)</span>
              </div>
              <div className="h-3 bg-white/10 rounded-full overflow-hidden">
                <div className="h-full bg-gradient-to-r from-orange-500 to-amber-500 rounded-full shadow-lg" style={{ width: `${100 - kioskPct}%` }} />
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-6 border border-white/10">
          <h3 className="font-black text-white mb-4">📱 Engagement Pelanggan</h3>
          <div className="space-y-3 text-sm">
            <div className="flex justify-between items-center py-2 border-b border-white/10">
              <span className="text-amber-200/80">Push Notification</span>
              <span className="font-black text-white">2,341</span>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-white/10">
              <span className="text-amber-200/80">WhatsApp Blast</span>
              <span className="font-black text-white">1,892</span>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-white/10">
              <span className="text-amber-200/80">Instagram Ads</span>
              <span className="font-black text-white">5,623</span>
            </div>
            <div className="flex justify-between items-center py-2">
              <span className="text-amber-200/80">Loyalty Points</span>
              <span className="font-black text-white">341 member</span>
            </div>
          </div>
        </div>
      </div>

      {/* Promotions list */}
      <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-6 border border-white/10">
        <div className="flex items-center justify-between mb-5">
          <h3 className="font-black text-white text-lg">🎟️ Semua Promosi</h3>
          <div className="flex gap-2">
            <span className="text-xs px-3 py-1 bg-emerald-500/20 text-emerald-300 rounded-full font-bold">Active: {promotions.filter(p => p.status === 'active').length}</span>
            <span className="text-xs px-3 py-1 bg-blue-500/20 text-blue-300 rounded-full font-bold">Scheduled: {promotions.filter(p => p.status === 'scheduled').length}</span>
            <span className="text-xs px-3 py-1 bg-slate-500/20 text-slate-300 rounded-full font-bold">Ended: {promotions.filter(p => p.status === 'ended').length}</span>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          {promotions.map(p => (
            <div key={p.id} className={`rounded-2xl p-5 bg-gradient-to-br ${p.color} text-white shadow-xl relative overflow-hidden`}>
              <div className="absolute -right-3 -top-3 text-8xl opacity-20">🎟️</div>
              <div className="relative">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <div className="text-xs opacity-80 font-bold">{p.id} • {p.type.toUpperCase()}</div>
                    <h4 className="text-xl font-black mt-1">{p.title}</h4>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-xs font-black ${
                    p.status === 'active' ? 'bg-white/30 backdrop-blur' : p.status === 'scheduled' ? 'bg-blue-400/40' : 'bg-black/40'
                  }`}>
                    {p.status === 'active' ? '🔥 AKTIF' : p.status === 'scheduled' ? '📅 JADWAL' : '⏸️ SELESAI'}
                  </span>
                </div>
                <p className="text-sm opacity-90 mb-4">{p.description}</p>
                <div className="flex items-end justify-between gap-3">
                  <div>
                    <div className="text-xs opacity-70">Diskon</div>
                    <div className="text-4xl font-black tracking-tight">{p.discount}</div>
                  </div>
                  <div className="text-xs text-right">
                    <div className="opacity-70">Target</div>
                    <div className="font-bold">{p.target}</div>
                    <div className="opacity-70 mt-1">{p.startDate} - {p.endDate}</div>
                  </div>
                </div>
                <button
                  onClick={() => toggleStatus(p.id)}
                  className="mt-4 w-full py-2 bg-white/20 hover:bg-white/30 rounded-xl text-sm font-bold backdrop-blur transition"
                >
                  {p.status === 'active' ? '⏸️ Nonaktifkan' : '▶️ Aktifkan'}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Create promotion modal */}
      {showCreate && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={() => setShowCreate(false)}>
          <div className="bg-gradient-to-br from-red-950 to-purple-950 border-2 border-red-500/30 rounded-3xl p-7 max-w-md w-full shadow-2xl" onClick={e => e.stopPropagation()}>
            <h3 className="text-2xl font-black text-white mb-5">🎯 Buat Promosi Baru</h3>
            <div className="space-y-3">
              <input type="text" placeholder="Judul Promosi (contoh: Diskon Lebaran)" className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder:text-amber-300/50 focus:outline-none focus:border-purple-400" />
              <textarea placeholder="Deskripsi promosi..." rows={2} className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder:text-amber-300/50 focus:outline-none focus:border-purple-400" />
              <div className="grid grid-cols-2 gap-3">
                <input type="text" placeholder="Diskon (contoh: 20% / B1G1)" className="px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder:text-amber-300/50 focus:outline-none focus:border-purple-400" />
                <select className="px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white focus:outline-none focus:border-purple-400">
                  <option className="bg-red-950">Percentage (%)</option>
                  <option className="bg-red-950">Fixed Amount</option>
                  <option className="bg-red-950">Buy 1 Get 1</option>
                </select>
              </div>
              <select className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white focus:outline-none focus:border-purple-400">
                <option className="bg-red-950">Target: Semua Menu</option>
                <option className="bg-red-950">Target: Seblak Original</option>
                <option className="bg-red-950">Target: Seblak Komplit</option>
                <option className="bg-red-950">Target: Wajib Coba</option>
              </select>
              <div className="grid grid-cols-2 gap-3">
                <input type="date" className="px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white focus:outline-none focus:border-purple-400" />
                <input type="date" className="px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white focus:outline-none focus:border-purple-400" />
              </div>
              <div className="flex gap-2 pt-2">
                <button onClick={() => setShowCreate(false)} className="flex-1 py-3 bg-white/10 hover:bg-white/15 rounded-xl font-bold text-white border border-white/20">Batal</button>
                <button onClick={() => { setShowCreate(false); alert('Promosi berhasil dibuat! 🌶️'); }} className="flex-1 py-3 bg-gradient-to-r from-purple-500 to-pink-600 text-white rounded-xl font-bold shadow-lg hover:shadow-xl">
                  🔥 Simpan Promosi
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
