import { useState, useRef, useEffect } from 'react';

interface Props {
  imageSrc: string;
  onCancel: () => void;
  onConfirm: (croppedDataUrl: string) => void;
  aspectRatio?: number; // e.g. 1 for square, 16/9 for wide
}

export default function ImageCropper({ imageSrc, onCancel, onConfirm, aspectRatio = 1 }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [img, setImg] = useState<HTMLImageElement | null>(null);
  const [scale, setScale] = useState(1);
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const [dragging, setDragging] = useState(false);
  const dragStart = useRef({ x: 0, y: 0, ox: 0, oy: 0 });

  const CANVAS_SIZE = 300;

  useEffect(() => {
    const image = new Image();
    image.onload = () => setImg(image);
    image.src = imageSrc;
  }, [imageSrc]);

  useEffect(() => {
    if (!img || !canvasRef.current) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.clearRect(0, 0, CANVAS_SIZE, CANVAS_SIZE);
    ctx.fillStyle = '#1e293b';
    ctx.fillRect(0, 0, CANVAS_SIZE, CANVAS_SIZE);

    // Calculate draw size to cover the crop area
    const imgAspect = img.width / img.height;
    const cropW = CANVAS_SIZE * aspectRatio;
    const cropH = CANVAS_SIZE;
    const cropX = (CANVAS_SIZE - cropW) / 2;

    let drawW, drawH;
    if (imgAspect > aspectRatio) {
      drawH = cropH * scale;
      drawW = drawH * imgAspect;
    } else {
      drawW = cropW * scale;
      drawH = drawW / imgAspect;
    }

    const dx = cropX + (cropW - drawW) / 2 + offset.x;
    const dy = (cropH - drawH) / 2 + offset.y;

    ctx.save();
    ctx.beginPath();
    ctx.rect(cropX, 0, cropW, cropH);
    ctx.clip();
    ctx.drawImage(img, dx, dy, drawW, drawH);
    ctx.restore();

    // Overlay dark outside crop area
    ctx.fillStyle = 'rgba(0,0,0,0.5)';
    ctx.fillRect(0, 0, cropX, CANVAS_SIZE);
    ctx.fillRect(cropX + cropW, 0, CANVAS_SIZE - (cropX + cropW), CANVAS_SIZE);

    // Crop border
    ctx.strokeStyle = '#f59e0b';
    ctx.lineWidth = 2;
    ctx.strokeRect(cropX, 0, cropW, cropH);

    // Grid lines
    ctx.strokeStyle = 'rgba(245, 158, 11, 0.3)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(cropX + cropW / 3, 0); ctx.lineTo(cropX + cropW / 3, CANVAS_SIZE);
    ctx.moveTo(cropX + cropW * 2 / 3, 0); ctx.lineTo(cropX + cropW * 2 / 3, CANVAS_SIZE);
    ctx.moveTo(cropX, CANVAS_SIZE / 3); ctx.lineTo(cropX + cropW, CANVAS_SIZE / 3);
    ctx.moveTo(cropX, CANVAS_SIZE * 2 / 3); ctx.lineTo(cropX + cropW, CANVAS_SIZE * 2 / 3);
    ctx.stroke();
  }, [img, scale, offset, aspectRatio]);

  const handleMouseDown = (e: React.MouseEvent) => {
    setDragging(true);
    dragStart.current = { x: e.clientX, y: e.clientY, ox: offset.x, oy: offset.y };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!dragging) return;
    setOffset({
      x: dragStart.current.ox + (e.clientX - dragStart.current.x),
      y: dragStart.current.oy + (e.clientY - dragStart.current.y),
    });
  };

  const handleMouseUp = () => setDragging(false);

  const handleConfirm = () => {
    if (!canvasRef.current) return;
    const canvas = canvasRef.current;
    const cropW = CANVAS_SIZE * aspectRatio;
    const cropX = (CANVAS_SIZE - cropW) / 2;
    const outCanvas = document.createElement('canvas');
    outCanvas.width = cropW;
    outCanvas.height = CANVAS_SIZE;
    const ctx = outCanvas.getContext('2d');
    if (!ctx) return;
    ctx.drawImage(canvas, cropX, 0, cropW, CANVAS_SIZE, 0, 0, cropW, CANVAS_SIZE);
    onConfirm(outCanvas.toDataURL('image/jpeg', 0.85));
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-gradient-to-br from-slate-900 to-red-950 rounded-3xl p-6 max-w-lg w-full border-2 border-amber-400/40 shadow-2xl">
        <h3 className="text-xl font-black text-white mb-1">✂️ Edit & Crop Gambar</h3>
        <p className="text-amber-300/70 text-sm mb-4">Geser & zoom untuk menyesuaikan, lalu klik Simpan</p>

        <div className="flex justify-center mb-4">
          <canvas
            ref={canvasRef}
            width={CANVAS_SIZE}
            height={CANVAS_SIZE}
            className="rounded-xl cursor-move border-2 border-amber-400/30"
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
            onMouseLeave={handleMouseUp}
          />
        </div>

        <div className="mb-4">
          <label className="text-xs font-bold text-amber-300 block mb-2">🔍 Zoom: {scale.toFixed(2)}x</label>
          <input
            type="range"
            min={0.5}
            max={3}
            step={0.05}
            value={scale}
            onChange={e => setScale(parseFloat(e.target.value))}
            className="w-full accent-amber-400"
          />
        </div>

        <div className="flex gap-2">
          <button onClick={onCancel} className="flex-1 py-2.5 bg-white/10 hover:bg-white/15 text-white rounded-xl font-bold border border-white/20">
            Batal
          </button>
          <button
            onClick={handleConfirm}
            className="flex-1 py-2.5 bg-gradient-to-r from-red-500 via-orange-500 to-amber-500 text-white rounded-xl font-bold shadow-lg hover:shadow-xl"
          >
            💾 Simpan Hasil
          </button>
        </div>
      </div>
    </div>
  );
}
