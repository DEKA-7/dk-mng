import { createContext, useContext, useState, ReactNode } from 'react';
import { MenuItem, Order, initialOrders, menuItems as defaultMenuItems } from '../data/menuData';

interface CartItem { item: MenuItem; qty: number; level: number; }

interface StoreContextType {
  cart: CartItem[];
  addToCart: (item: MenuItem, level?: number) => void;
  removeFromCart: (id: string) => void;
  updateQty: (id: string, qty: number) => void;
  updateLevel: (id: string, level: number) => void;
  clearCart: () => void;
  cartTotal: number;
  cartCount: number;
  orders: Order[];
  addOrder: (order: Omit<Order, 'id' | 'createdAt'>) => string;
  updateOrderStatus: (id: string, status: Order['status']) => void;
  getUniqueCustomerName: (name: string) => string;
  dailyStats: {
    revenue: number;
    orders: number;
    itemsSold: number;
    avgTicket: number;
    kioskOrders: number;
    cashierOrders: number;
  };
  editMenuItem: (id: string, updates: Partial<MenuItem>) => void;
  addMenuItem: (item: Omit<MenuItem, 'id'>) => void;
  deleteMenuItem: (id: string) => void;
  menuItems: MenuItem[];
  setOrders: (orders: Order[]) => void;
}

const StoreContext = createContext<StoreContextType | null>(null);

export function levelPrice(level: number): number {
  if (level >= 7) return 4000;
  if (level === 6) return 2000;
  return 0;
}

export function StoreProvider({ children }: { children: ReactNode }) {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [orders, setOrders] = useState<Order[]>(initialOrders);
  const [menuItems, setMenuItems] = useState<MenuItem[]>(() => {
    const s = localStorage.getItem('seblakidr_menu');
    return s ? JSON.parse(s) : require('../data/menuData').menuItems;
  });

  // Persist orders
  useState(() => {
    const s = localStorage.getItem('seblakidr_orders');
    if (s) setOrders(JSON.parse(s).map((o: Order) => ({ ...o, createdAt: new Date(o.createdAt) })));
  });

  const persistOrders = (newOrders: Order[]) => {
    localStorage.setItem('seblakidr_orders', JSON.stringify(newOrders));
  };

  const persistMenu = (items: MenuItem[]) => {
    localStorage.setItem('seblakidr_menu', JSON.stringify(items));
  };

  const addToCart = (item: MenuItem, level: number = 1) => {
    setCart(prev => {
      const existing = prev.find(c => c.item.id === item.id && c.level === level);
      if (existing) return prev.map(c => (c.item.id === item.id && c.level === level) ? { ...c, qty: c.qty + 1 } : c);
      return [...prev, { item, qty: 1, level }];
    });
  };
  const removeFromCart = (id: string) => setCart(prev => prev.filter(c => c.item.id !== id));
  const updateQty = (id: string, qty: number) => {
    if (qty <= 0) return removeFromCart(id);
    setCart(prev => prev.map(c => c.item.id === id ? { ...c, qty } : c));
  };
  const updateLevel = (id: string, level: number) => {
    setCart(prev => prev.map(c => c.item.id === id ? { ...c, level } : c));
  };
  const clearCart = () => setCart([]);

  const cartTotal = cart.reduce((sum, c) => sum + (c.item.price + levelPrice(c.level)) * c.qty, 0);
  const cartCount = cart.reduce((sum, c) => sum + c.qty, 0);

  const getUniqueCustomerName = (name: string): string => {
    const existing = orders.filter(o => o.customerName === name || o.customerName?.startsWith(name + ' #'));
    if (existing.length === 0) return name;
    const code = Math.random().toString(36).slice(2, 6).toUpperCase();
    return `${name} #${code}`;
  };

  const addOrder = (order: Omit<Order, 'id' | 'createdAt'>): string => {
    const id = `SDR-${Math.floor(10000 + Math.random() * 90000)}`;
    const newOrder: Order = { ...order, id, createdAt: new Date() };
    const newOrders = [newOrder, ...orders];
    setOrders(newOrders);
    persistOrders(newOrders);
    return id;
  };

  const updateOrderStatus = (id: string, status: Order['status']) => {
    const newOrders = orders.map(o => o.id === id ? { ...o, status } : o);
    setOrders(newOrders);
    persistOrders(newOrders);
  };

  const editMenuItem = (id: string, updates: Partial<MenuItem>) => {
    const newItems = menuItems.map(m => m.id === id ? { ...m, ...updates } : m);
    setMenuItems(newItems);
    persistMenu(newItems);
  };

  const addMenuItem = (item: Omit<MenuItem, 'id'>) => {
    const newItem: MenuItem = { ...item, id: `M${Date.now()}` };
    const newItems = [...menuItems, newItem];
    setMenuItems(newItems);
    persistMenu(newItems);
  };

  const deleteMenuItem = (id: string) => {
    const newItems = menuItems.filter(m => m.id !== id);
    setMenuItems(newItems);
    persistMenu(newItems);
  };

  const paidOrders = orders.filter(o => o.status !== 'cancelled');
  const dailyStats = {
    revenue: paidOrders.reduce((s, o) => s + o.total, 0),
    orders: paidOrders.length,
    itemsSold: paidOrders.reduce((s, o) => s + o.items.reduce((a, i) => a + i.qty, 0), 0),
    avgTicket: paidOrders.length ? paidOrders.reduce((s, o) => s + o.total, 0) / paidOrders.length : 0,
    kioskOrders: paidOrders.filter(o => o.type === 'kiosk').length,
    cashierOrders: paidOrders.filter(o => o.type === 'cashier').length,
  };

  return (
    <StoreContext.Provider value={{
      cart, addToCart, removeFromCart, updateQty, updateLevel, clearCart,
      cartTotal, cartCount, orders, addOrder, updateOrderStatus,
      getUniqueCustomerName, dailyStats, editMenuItem, addMenuItem, deleteMenuItem,
      menuItems, setOrders,
    }}>
      {children}
    </StoreContext.Provider>
  );
}

export function useStore() {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error('useStore must be used within StoreProvider');
  return ctx;
}
