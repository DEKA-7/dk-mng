import { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import { User, defaultUsers } from '../data/users';

interface AuthContextType {
  user: User | null;
  users: User[];
  login: (username: string, password: string) => { success: boolean; message?: string };
  logout: () => void;
  addUser: (user: Omit<User, 'role'> & { role: User['role'] }) => void;
  updateUser: (username: string, updates: Partial<User>) => void;
  deleteUser: (username: string) => void;
  isAdmin: boolean;
  canAccess: (module: string) => boolean;
}

const AuthContext = createContext<AuthContextType | null>(null);

const STORAGE_KEY = 'seblakidr_users';
const AUTH_KEY = 'seblakidr_auth';

export function AuthProvider({ children }: { children: ReactNode }) {
  const [users, setUsers] = useState<User[]>(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    return stored ? JSON.parse(stored) : defaultUsers;
  });
  const [user, setUser] = useState<User | null>(() => {
    const stored = localStorage.getItem(AUTH_KEY);
    return stored ? JSON.parse(stored) : null;
  });

  useEffect(() => { localStorage.setItem(STORAGE_KEY, JSON.stringify(users)); }, [users]);
  useEffect(() => {
    if (user) localStorage.setItem(AUTH_KEY, JSON.stringify(user));
    else localStorage.removeItem(AUTH_KEY);
  }, [user]);

  const login = (username: string, password: string) => {
    const u = users.find(x => x.username === username);
    if (!u) return { success: false, message: 'Username tidak ditemukan' };
    if (u.password !== password) return { success: false, message: 'Password salah' };
    setUser(u);
    return { success: true };
  };

  const logout = () => setUser(null);

  const addUser = (newUser: User) => {
    if (users.find(u => u.username === newUser.username)) return;
    setUsers(prev => [...prev, newUser]);
  };

  const updateUser = (username: string, updates: Partial<User>) => {
    setUsers(prev => prev.map(u => u.username === username ? { ...u, ...updates } : u));
  };

  const deleteUser = (username: string) => {
    if (username === 'admin') return;
    setUsers(prev => prev.filter(u => u.username !== username));
  };

  const isAdmin = user?.role === 'admin';

  const canAccess = (module: string): boolean => {
    if (!user) return false;
    if (user.role === 'admin') return true;
    if (user.role === module) return true;
    return false;
  };

  return (
    <AuthContext.Provider value={{ user, users, login, logout, addUser, updateUser, deleteUser, isAdmin, canAccess }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
