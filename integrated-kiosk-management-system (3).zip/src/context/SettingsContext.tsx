import { createContext, useContext, useState, ReactNode, useEffect } from 'react';

export interface BusinessProfile {
  name: string;
  tagline: string;
  logo: string | null;
  phone: string;
  address: string;
  whatsapp: string;
  currency: string;
}

export interface ThemeSettings {
  backgroundImage: string | null;
  backgroundColor: string;
  accentColor: string;
  themeMode: 'dark' | 'light' | 'custom';
}

interface SettingsContextType {
  profile: BusinessProfile;
  updateProfile: (updates: Partial<BusinessProfile>) => void;
  theme: ThemeSettings;
  updateTheme: (updates: Partial<ThemeSettings>) => void;
  compressImage: (file: File, maxSizeMB?: number) => Promise<string>;
}

const SettingsContext = createContext<SettingsContextType | null>(null);

const defaultProfile: BusinessProfile = {
  name: 'SeblakIDR',
  tagline: 'Pedasnya Nampol, Rasanya Nagih!',
  logo: null,
  phone: '081-391-674-116',
  address: 'Jl. Pedas Mercon No. 69, Jakarta',
  whatsapp: '081391674116',
  currency: 'Rp',
};

const defaultTheme: ThemeSettings = {
  backgroundImage: null,
  backgroundColor: '#7f1d1d',
  accentColor: '#f59e0b',
  themeMode: 'dark',
};

export function SettingsProvider({ children }: { children: ReactNode }) {
  const [profile, setProfile] = useState<BusinessProfile>(() => {
    const s = localStorage.getItem('seblakidr_profile');
    return s ? JSON.parse(s) : defaultProfile;
  });
  const [theme, setTheme] = useState<ThemeSettings>(() => {
    const s = localStorage.getItem('seblakidr_theme');
    return s ? JSON.parse(s) : defaultTheme;
  });

  useEffect(() => { localStorage.setItem('seblakidr_profile', JSON.stringify(profile)); }, [profile]);
  useEffect(() => { localStorage.setItem('seblakidr_theme', JSON.stringify(theme)); }, [theme]);

  const updateProfile = (updates: Partial<BusinessProfile>) => setProfile(prev => ({ ...prev, ...updates }));
  const updateTheme = (updates: Partial<ThemeSettings>) => setTheme(prev => ({ ...prev, ...updates }));

  const compressImage = (file: File, maxSizeMB = 1): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new Image();
        img.onload = () => {
          const maxDim = 1200;
          let { width, height } = img;
          if (width > maxDim || height > maxDim) {
            if (width > height) { height = height * (maxDim / width); width = maxDim; }
            else { width = width * (maxDim / height); height = maxDim; }
          }
          const canvas = document.createElement('canvas');
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          if (!ctx) return reject(new Error('No canvas ctx'));
          ctx.drawImage(img, 0, 0, width, height);
          const dataUrl = canvas.toDataURL('image/jpeg', 0.75);
          // Check size, compress more if needed
          const sizeKB = (dataUrl.length * 3) / 4 / 1024;
          if (sizeKB > maxSizeMB * 1024) {
            const newData = canvas.toDataURL('image/jpeg', 0.5);
            resolve(newData);
          } else {
            resolve(dataUrl);
          }
        };
        img.onerror = reject;
        img.src = e.target?.result as string;
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  };

  return (
    <SettingsContext.Provider value={{ profile, updateProfile, theme, updateTheme, compressImage }}>
      {children}
    </SettingsContext.Provider>
  );
}

export function useSettings() {
  const ctx = useContext(SettingsContext);
  if (!ctx) throw new Error('useSettings must be used within SettingsProvider');
  return ctx;
}
