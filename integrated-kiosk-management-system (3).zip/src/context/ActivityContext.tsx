import { createContext, useContext, useState, ReactNode, useEffect } from 'react';

export interface ActivityEntry {
  id: string;
  timestamp: Date;
  type: 'login' | 'logout' | 'order' | 'payment' | 'edit' | 'settings' | 'backup' | 'error';
  user: string;
  action: string;
  details?: string;
  ip?: string;
}

interface ActivityContextType {
  activities: ActivityEntry[];
  log: (entry: Omit<ActivityEntry, 'id' | 'timestamp'>) => void;
  clear: () => void;
  exportCSV: () => string;
}

const ActivityContext = createContext<ActivityContextType | null>(null);

export function ActivityProvider({ children }: { children: ReactNode }) {
  const [activities, setActivities] = useState<ActivityEntry[]>(() => {
    const s = localStorage.getItem('seblakidr_activities');
    return s ? JSON.parse(s).map((a: ActivityEntry) => ({ ...a, timestamp: new Date(a.timestamp) })) : [];
  });

  useEffect(() => {
    localStorage.setItem('seblakidr_activities', JSON.stringify(activities.slice(0, 500)));
  }, [activities]);

  const log = (entry: Omit<ActivityEntry, 'id' | 'timestamp'>) => {
    const newEntry: ActivityEntry = {
      ...entry,
      id: `ACT-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      timestamp: new Date(),
    };
    setActivities(prev => [newEntry, ...prev].slice(0, 500));
  };

  const clear = () => setActivities([]);

  const exportCSV = () => {
    const header = 'ID,Tanggal,Waktu,Tipe,User,Aksi,Detail\n';
    const rows = activities.map(a => [
      a.id,
      a.timestamp.toLocaleDateString('id-ID'),
      a.timestamp.toLocaleTimeString('id-ID'),
      a.type,
      a.user,
      `"${a.action.replace(/"/g, '""')}"`,
      `"${(a.details || '').replace(/"/g, '""')}"`,
    ].join(',')).join('\n');
    return header + rows;
  };

  return (
    <ActivityContext.Provider value={{ activities, log, clear, exportCSV }}>
      {children}
    </ActivityContext.Provider>
  );
}

export function useActivity() {
  const ctx = useContext(ActivityContext);
  if (!ctx) throw new Error('useActivity must be used within ActivityProvider');
  return ctx;
}
